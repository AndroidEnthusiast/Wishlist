# Wishlist: standing notes for Claude Code

Read this first. The long history and the open to-do list are in `docs/HANDOFF.md`; every version's technical notes are in `README.md`.

## Who you are working with
- The owner is a beginner. They work from an Android phone and a Chromebook (browser only), with no terminal or IDE. They write in plain English.
- Explain in short, exact, tap-by-tap steps. Name the real buttons ("Add file", "Upload files", "Merge pull request"). One thing at a time. No jargon unless you explain it in a few words.
- Be honest about testing: always say what you ran and what you could NOT check (see "Cannot be checked here" below).
- No iOS app is planned. iPhone and computer users edit shared lists in the browser editor (`web/edit.html`).

## What this is
An Android wishlist app (Kotlin, Jetpack Compose, Material 3, package `com.wishlist.app`) plus web pages on GitHub Pages plus a free Supabase backend.
- Repo `AndroidEnthusiast/Wishlist`; site `https://androidenthusiast.github.io/Wishlist/`; Supabase URL and the public publishable key are in `app/src/main/java/com/wishlist/app/Config.kt` and at the top of `web/index.html` and `web/edit.js` (they are meant to be public).
- Lists are link-only (never public). Friends open `?c=CODE` and can reserve gifts. The owner and invited editors never see who reserved what.
- Shared lists: an invite link `?j=KEY` lets people edit together, in the app or in the browser (`web/edit.html`).

## How it is built and published
- ONE workflow, `.github/workflows/build.yml`, runs on every push: job `build` (Gradle assembleDebug, then replaces the GitHub release `latest` with `Wishlist.apk`) and job `pages` (publishes the `web/` folder). The invite page links to that APK.
- The workflow still unzips `wishlist-android.zip` if one exists. The project moved to Claude Code, so that zip should no longer exist. Never recreate it or ask the owner to upload it (it would overwrite newer work).
- Change flow: you push a branch, the owner reviews and merges the pull request on GitHub; merging to `main` is what updates the app download and the web pages. Workflow files are often refused when pushed from here: if `build.yml` must change, give the owner the exact edit to make in GitHub's own editor.
- APK signing uses the fixed key `app/debug.keystore` so updates install over the old app. Do not change it. A Play Store release would need a proper private key.
- Supabase scripts (`supabase-*.sql`) and the edge function are run by the owner by hand in the Supabase dashboard. If you change one, say so clearly and give the exact steps. The SQL files are safe to run again.
- Bump `versionName`/`versionCode` in `app/build.gradle.kts` when app code changes, and add one bullet per version to `README.md` in the same style.

## Where things are
- `app/src/main/java/com/wishlist/app/`: `MainActivity.kt` (screens), `Data.kt` (`Wish`, `Repo`), `Shared.kt` + `SharedUi.kt` (shared lists, online saving), `Cloud.kt` (my own list online), `Fetch.kt` + `Browser.kt` (reading product pages), `MostWanted.kt` (star and its effect), `Delete.kt` + `DeleteUi.kt` + `Trash.kt` (delete with Undo), `Sorting.kt` + `Browse.kt`, `Categories.kt`, `Sizes.kt`, `History.kt` + `PriceHistory.kt` + `ChartMath.kt`, `PriceWorker.kt` + `Alerts.kt`, `Settings.kt`, `Theme.kt`.
- `web/index.html` + `web/wishlist.css`: the friends' page and the invite page. `web/edit.html`, `edit.js`, `edit.css`: the browser editor. `web/parse.js`: reads a product page.
- `supabase/functions/fetch-page/index.ts`: the helper that loads a shop page for the browser editor (the browser may not load other sites itself).
- `tests/`: automated checks for everything under `web/` and the helper (see below).

## Rules that must stay true
1. A wish is a JSON object with: id, url, title, desc, image, price, old, cur, cat, got, and only when set: star, note, size, by. A NEW FIELD must be added in all of: `Wish`, `wishToJson`, `wishFromJson`, `Shared.changedFields`, `Shared.applyFields` (app) and `normWish`, `wishJson`, `FIELDS` in `web/edit.js`; also show it on `web/index.html` if friends should see it.
2. `Fetch.kt` and `web/parse.js` do the same job with the same logic (prices, currencies, Amazon, Funda). Change both together and extend `tests/parse/parse_test.js`.
3. Shared lists save one wish at a time and only the fields that changed (`wl_sh_put_item(p_key, p_item, p_fields)`), so two people never overwrite each other. Same field at the same moment: the later save wins. The browser editor (`edit.js`) follows the same rules as `Shared.kt`: change shows at once, saves in the background, a failed save is undone with a message, a refresh answer older than the last local change is ignored, deletes are final only after 10 s of Undo (or when the page closes), a picture is deleted online only by the person who replaced it.
4. Reservations are fetched only by the friends' page and friends' devices. No editor function or the owner's app may fetch them.
5. Only the phone that created a list can make a new invite link or delete the list.
6. Text on screen: English, short and kind.

## Testing
- Run before every pull request that touches `web/` or the helper: `cd tests && npm install && npx playwright install chromium && bash run-all.sh`. All suites must say passed. Add or update checks together with changes. Details in `tests/README.md`.
- The Android code is only compiled by GitHub. If you can run Gradle with an Android SDK in your sandbox, try `gradle assembleDebug`; if not, check bracket balance and syntax carefully, say so, and ask the owner to look at the Actions tab after merging (a red cross means: ask them to open the failed job and paste the error lines).
- Earlier sessions also ran local Kotlin harnesses (real `Shared.kt`, delete/undo, sorting, categories) with stand-ins for Android; they are not in this repo.

## Cannot be checked here (say so, don't claim it works)
- Anything on the real Supabase, the real shops (Amazon often blocks server requests), a real iPhone/Safari, or how the Compose screens look and feel on a phone.
- The browser editor's picture upload sends the headers `x-edit-key` and `cache-control` to Supabase storage from another website. If a real browser refuses, the wish is saved without the picture and says so; check Supabase storage CORS.
- The helper function must be deployed and have its JWT check switched off (function Settings, "Verify JWT with legacy secret" off, then Save). Without it, link auto-fill in the browser editor shows "Couldn't read that page".
