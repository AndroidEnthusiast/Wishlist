# Wishlist (Android)
Kotlin + Jetpack Compose (Material 3). Link parsing with Jsoup, images with Coil, price-drop checks with WorkManager.
Font: Google Sans (SIL OFL, see FONT-LICENSE-OFL.txt).
Build: `gradle assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk

## Online sharing (v2)
Free Supabase project. Run `supabase-setup.sql` once in the Supabase SQL editor, then put the Project URL and
publishable key in `app/src/main/java/com/wishlist/app/Config.kt`. Without them the app works as before and the
share button falls back to a plain-text export.
- Owner: menu -> Settings -> Sharing (or the share icon). Friends get a code like WL-ABCD2345.
- Friends: menu -> Open a friend's list, or share the invite text to the Wishlist app.
- Reservations are only ever fetched by friends' phones. The owner's app never requests them.
