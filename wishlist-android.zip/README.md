# Wishlist (Android)
Kotlin + Jetpack Compose (Material 3). Link parsing with Jsoup, images with Coil, price-drop checks with WorkManager.
Font: Google Sans (SIL OFL, see FONT-LICENSE-OFL.txt).
Build: `gradle assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk

## Online sharing (v2.2)
Free Supabase project plus a static web page on GitHub Pages.
- Run `supabase-setup.sql` once in the Supabase SQL editor. Put the Project URL and publishable key in
  `app/src/main/java/com/wishlist/app/Config.kt` (and at the top of `web/index.html`).
- Upload `web/index.html`, `web/og.png` and `web/icon.png` to the repo root (same names) and turn on GitHub Pages (Settings -> Pages ->
  Deploy from a branch -> main / root). Friends open `https://<user>.github.io/<repo>/?c=CODE`.
- Owner: menu -> Settings -> Sharing (or the share icon) sends that link. No app needed for friends.
- Reservations are only ever fetched by the web page and friends' devices. The owner's app never requests them.
- Without Supabase values the share button falls back to a plain-text export.
- Wishes can be edited (pencil icon on each card). Editing syncs to the shared page.
- Link reading (v2.3): plain request first; if the store blocks it or no price is found, the page is loaded in a hidden in-app browser (Browser.kt). Funda/Etsy-style pages are handled by text and JSON-LD fallbacks in Fetch.kt.
- Views (v2.4): category dropdown + three view buttons (large cards, two per row, images only with price tag). The choice is remembered. In images-only view, tapping a tile opens a detail dialog with Edit / Got it / Remove / Open in store.
- Alerts (v2.5): Alerts.kt holds the schedule, notification and settings shortcuts. Settings -> Price alerts has interval (1/3/6/12/24 h), last check time, Check now, Test notification, and shortcuts to battery/notification settings. Notification: title 'Price drop on your wishlist', text '<item> is now X (was Y, -Z%)'.
- Menu (v2.6): side menu is ~72% of the screen width, the screen behind it blurs (Android 12+), and the menu button is drawn above the menu as an animated hamburger that spins into an X. Screens keep an empty MenuSlot() where the button sits.
- Add/Edit dialog (v2.7): no Paste button; pasting a whole link fills in the details automatically (Fetch details stays as a retry). The link is optional, so custom wishes work. ImageBlock shows a dashed '+ Add image' block that opens the photo picker; the picture is copied into the app (ImageStore.kt, max 1024 px). Pictures chosen this way are not uploaded to Supabase, so friends on the web page see a gift icon for them.
- Photo sharing (v2.8): run `supabase-photos.sql` once. Pictures you add yourself are uploaded as small (600 px) JPEG copies to the public Supabase bucket `wish-photos` under `<code>/<file>.jpg`; only the list owner (secret `x-owner-token` header) can add or delete them. Pictures are removed again when the wish or picture is removed, or when sharing stops. Settings -> Sharing shows the upload status.
