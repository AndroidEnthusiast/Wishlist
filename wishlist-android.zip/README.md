# Wishlist (Android)
Kotlin + Jetpack Compose (Material 3). Link parsing with Jsoup, images with Coil, price-drop checks with WorkManager.
Font: Google Sans (SIL OFL, see FONT-LICENSE-OFL.txt).
Build: `gradle assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk
