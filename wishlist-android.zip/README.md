# Wishlist (Android)
Kotlin + Jetpack Compose (Material 3). Link parsing with Jsoup, images with Coil, price-drop checks with WorkManager.
Font: Google Sans (SIL OFL, see FONT-LICENSE-OFL.txt).
Build: `gradle assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk

## Online sharing (v2.1)
Free Supabase project plus a static web page on GitHub Pages.
- Run `supabase-setup.sql` once in the Supabase SQL editor. Put the Project URL and publishable key in
  `app/src/main/java/com/wishlist/app/Config.kt` (and at the top of `web/index.html`).
- Upload `web/index.html` as `index.html` in the repo root and turn on GitHub Pages (Settings -> Pages ->
  Deploy from a branch -> main / root). Friends open `https://<user>.github.io/<repo>/?c=CODE`.
- Owner: menu -> Settings -> Sharing (or the share icon) sends that link. No app needed for friends.
- Reservations are only ever fetched by the web page and friends' devices. The owner's app never requests them.
- Without Supabase values the share button falls back to a plain-text export.
