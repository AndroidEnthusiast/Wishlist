-- Shared wishlists setup (two or more people edit one list). Run this ONCE in Supabase:
-- SQL Editor -> New query -> paste -> Run.
-- Run supabase-setup.sql and supabase-photos.sql first (you already did). Safe to run again later; it won't delete anything.
--
-- How it works:
--  * A shared list is a normal row in wl_lists, so the friends' page (?c=CODE) and reservations work unchanged.
--  * It also has a secret "edit key". Whoever knows the key can add, change and delete wishes (the invite link contains it).
--  * The creator's phone also keeps the list's owner token. Only that can reset the key or delete the list.
--  * Editors never see reservations: none of the functions below return them.

alter table wl_lists add column if not exists edit_key text;
create unique index if not exists wl_lists_edit_key_uq on wl_lists (edit_key) where edit_key is not null;

-- Finds the list for an edit key. Raises 'not allowed' for a wrong key.
create or replace function wl_sh_code(p_key text)
returns text language plpgsql stable security definer set search_path = public as $$
declare v text;
begin
  if p_key is null or length(p_key) < 16 then raise exception 'not allowed'; end if;
  select code into v from wl_lists where edit_key = p_key;
  if v is null then raise exception 'not allowed'; end if;
  return v;
end $$;

create or replace function wl_sh_create(p_code text, p_key text, p_token text, p_name text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_key is null or length(p_key) < 16 or p_token is null or length(p_token) < 16 then
    raise exception 'bad key';
  end if;
  insert into wl_lists (code, owner_token, name, edit_key) values (p_code, p_token, p_name, p_key);
end $$;

-- The whole list for an editor: name, categories and wishes (no reservations). Null if the key is wrong.
create or replace function wl_sh_get(p_key text)
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'code', l.code,
    'name', l.name,
    'cats', l.cats,
    'items', coalesce(
      (select jsonb_agg(i.data order by i.id desc) from wl_items i where i.list_code = l.code),
      '[]'::jsonb)
  ) from wl_lists l
  where p_key is not null and length(p_key) >= 16 and l.edit_key = p_key
$$;

-- Just enough for the invite page: the name and how many wishes. Null if the key is wrong.
create or replace function wl_sh_info(p_key text)
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'name', l.name,
    'count', (select count(*) from wl_items i where i.list_code = l.code and i.id > 0)
  ) from wl_lists l
  where p_key is not null and length(p_key) >= 16 and l.edit_key = p_key
$$;

-- Adds or replaces ONE wish. Other wishes are not touched, so two people can edit at the same time.
create or replace function wl_sh_put_item(p_key text, p_item jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare v_code text; v_id bigint;
begin
  v_code := wl_sh_code(p_key);
  v_id := (p_item->>'id')::bigint;
  if v_id is null or v_id <= 0 then raise exception 'bad id'; end if;
  if length(p_item::text) > 20000 then raise exception 'too big'; end if;
  insert into wl_items (list_code, id, data) values (v_code, v_id, p_item)
  on conflict (list_code, id) do update set data = excluded.data;
  update wl_lists set updated_at = now() where code = v_code;
end $$;

-- Deletes ONE wish (and any reservation on it).
create or replace function wl_sh_del_item(p_key text, p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
declare v_code text;
begin
  v_code := wl_sh_code(p_key);
  if p_id <= 0 then raise exception 'bad id'; end if;
  delete from wl_items where list_code = v_code and id = p_id;
  update wl_lists set updated_at = now() where code = v_code;
end $$;

-- Name, categories and the note for friends (kept as the special item with id 0, like on a normal list).
create or replace function wl_sh_set_meta(p_key text, p_name text, p_cats jsonb, p_about text)
returns void language plpgsql security definer set search_path = public as $$
declare v_code text;
begin
  v_code := wl_sh_code(p_key);
  update wl_lists set name = p_name, cats = p_cats, updated_at = now() where code = v_code;
  if coalesce(p_about, '') = '' then
    delete from wl_items where list_code = v_code and id = 0;
  else
    insert into wl_items (list_code, id, data)
    values (v_code, 0, jsonb_build_object('id', 0, 'kind', 'about', 'about', left(p_about, 300), 'url', '', 'title', ''))
    on conflict (list_code, id) do update set data = excluded.data;
  end if;
end $$;

-- Creator only: gives the list a new edit key. The old invite link stops working for everyone.
create or replace function wl_sh_reset_key(p_code text, p_token text, p_new_key text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_new_key is null or length(p_new_key) < 16 then raise exception 'bad key'; end if;
  update wl_lists set edit_key = p_new_key
    where code = p_code and owner_token = p_token and edit_key is not null;
  if not found then raise exception 'not allowed'; end if;
end $$;

-- Pictures: editors may add and delete pictures in the folder of a shared list.
-- (Same check as before, plus the edit key sent in a header called x-edit-key.)
create or replace function public.wl_owner_ok(p_code text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from wl_lists
    where code = p_code
      and (
        owner_token = coalesce(nullif(current_setting('request.headers', true), '')::json ->> 'x-owner-token', '')
        or (edit_key is not null
            and edit_key = coalesce(nullif(current_setting('request.headers', true), '')::json ->> 'x-edit-key', ''))
      )
  )
$$;

grant execute on function
  wl_sh_create(text, text, text, text),
  wl_sh_get(text),
  wl_sh_info(text),
  wl_sh_put_item(text, jsonb),
  wl_sh_del_item(text, bigint),
  wl_sh_set_meta(text, text, jsonb, text),
  wl_sh_reset_key(text, text, text),
  public.wl_owner_ok(text)
to anon;
