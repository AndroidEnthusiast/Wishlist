package com.wishlist.app

import android.content.Context
import android.content.Intent
import androidx.compose.material3.SnackbarHostState
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.SecureRandom
import java.util.UUID

/** Keeps the online copy of the owner's list up to date, and handles share codes. */
object Sync {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private val EMBEDDED = Regex("WL-([A-HJ-NP-Z2-9]{8})")
    private val BARE = Regex("[A-HJ-NP-Z2-9]{8}")

    /** Pushes the list online shortly after the last change. Does nothing unless the list is shared. */
    @Synchronized
    fun push() {
        if (Repo.shareCode == null) return
        job?.cancel()
        job = scope.launch {
            delay(1500)
            try {
                pushNow()
            } catch (e: Exception) {
            }
        }
    }

    suspend fun pushNow() {
        val code = Repo.shareCode ?: return
        val token = Repo.ownerToken ?: return
        Cloud.pushList(code, token, Repo.listName, Repo.cats, Repo.wishes)
    }

    /** Makes the list available online (first time only) and returns its share code. */
    suspend fun publish(c: Context): String {
        val existing = Repo.shareCode
        if (existing != null) {
            pushNow()
            return existing
        }
        val code = newCode()
        val token = UUID.randomUUID().toString()
        Cloud.createList(code, token, Repo.listName)
        Repo.setShare(c, code, token)
        pushNow()
        return code
    }

    suspend fun unpublish(c: Context) {
        val code = Repo.shareCode ?: return
        val token = Repo.ownerToken ?: return
        Cloud.deleteList(code, token)
        Repo.setShare(c, null, null)
    }

    private fun newCode(): String {
        val r = SecureRandom()
        return (1..8).map { ALPHABET[r.nextInt(ALPHABET.length)] }.joinToString("")
    }

    /** Finds a "WL-XXXXXXXX" code inside shared text. */
    fun embeddedCode(s: String): String? = EMBEDDED.find(s.uppercase())?.groupValues?.get(1)

    /** Accepts "WL-ABCD2345", "abcd2345", or a whole shared message. */
    fun parseCode(s: String): String? {
        embeddedCode(s)?.let { return it }
        val bare = s.uppercase().replace(Regex("[^A-Z0-9]"), "")
        for (cand in listOf(bare, bare.removePrefix("WL"))) {
            if (BARE.matches(cand)) return cand
        }
        return null
    }
}

fun shareLink(code: String): String = Config.SHARE_URL.trimEnd('/') + "/?c=" + code

fun inviteText(name: String, code: String): String =
    "Here’s my wishlist “$name”. Open the link and tap Reserve on a gift so nobody doubles up. " +
        "I won’t see what’s reserved.\n\n" + shareLink(code)

fun shareText(c: Context, title: String, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    c.startActivity(Intent.createChooser(send, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

/** Plain-text export of the whole list (works without any online setup). */
fun shareList(c: Context, l: List<Wish>) {
    val body = l.joinToString("\n\n") { w ->
        val p = if (w.price != null) " - " + money(w.price, w.currency) else ""
        w.title + p + "\n" + w.url
    }
    shareText(c, "Share wishlist", "${Repo.listName}\n\n$body")
}

/** Shares the online list code (publishing the list first if needed). Falls back to plain text if sharing isn't set up. */
fun startShare(c: Context, scope: CoroutineScope, snack: SnackbarHostState) {
    if (!Config.enabled) {
        shareList(c, Repo.wishes)
        return
    }
    scope.launch {
        try {
            val code = Sync.publish(c)
            shareText(c, "Share wishlist", inviteText(Repo.listName, code))
        } catch (e: Exception) {
            snack.showSnackbar("Couldn’t share: " + (e.message ?: "no connection"))
        }
    }
}

/** Sends this installed app's APK through the Android share sheet. */
suspend fun shareApk(c: Context) {
    val uri = withContext(Dispatchers.IO) {
        val dir = File(c.cacheDir, "apk")
        dir.mkdirs()
        val dst = File(dir, "Wishlist.apk")
        File(c.applicationInfo.sourceDir).copyTo(dst, overwrite = true)
        FileProvider.getUriForFile(c, c.packageName + ".files", dst)
    }
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "application/vnd.android.package-archive"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    c.startActivity(Intent.createChooser(send, "Share Wishlist app").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
