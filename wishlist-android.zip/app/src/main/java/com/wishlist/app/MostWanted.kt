package com.wishlist.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** The gold of the "Most wanted" label, and the dark brown text on it. Same in light and dark mode. */
val StarGold = Color(0xFFFFC83D)
val StarInk = Color(0xFF3B2A00)

/** A five-pointed star: solid when [filled], an outline otherwise. */
@Composable
fun StarIcon(filled: Boolean, tint: Color, iconSize: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(iconSize)) {
        val w = this.size.width
        val cx = w / 2f
        val cy = this.size.height / 2f + w * 0.03f
        val outer = w * 0.48f
        val inner = outer * 0.42f
        val p = Path()
        for (i in 0 until 10) {
            val a = (-90.0 + i * 36.0) * PI / 180.0
            val r = if (i % 2 == 0) outer else inner
            val x = (cx + r * cos(a)).toFloat()
            val y = (cy + r * sin(a)).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        if (filled) drawPath(p, tint)
        else drawPath(p, tint, style = Stroke(width = w * 0.09f, join = StrokeJoin.Round))
    }
}

/**
 * The gold "Most wanted" label for the corner of a picture. [showLabel] false gives just the star (small cards).
 * With [onClick] the owner can tap it to take the star away again.
 */
@Composable
fun MostWantedBadge(showLabel: Boolean, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    val shape = RoundedCornerShape(8.dp)
    var m = modifier.clip(shape).background(StarGold)
    m = if (onClick != null) {
        m.clickable(onClickLabel = "Remove from most wanted", role = Role.Button, onClick = onClick)
    } else if (!showLabel) {
        m.semantics { contentDescription = "Most wanted" }
    } else m
    Row(
        m.padding(horizontal = if (showLabel) 8.dp else 5.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        StarIcon(true, StarInk, 14.dp)
        if (showLabel) {
            Spacer(Modifier.width(4.dp))
            Text("Most wanted", style = MaterialTheme.typography.labelMedium, color = StarInk)
        }
        // A small cross when you can tap the label to take it away again.
        if (onClick != null) {
            Spacer(Modifier.width(6.dp))
            Icon(Icons.Default.Close, null, Modifier.size(14.dp), tint = StarInk)
        }
    }
}

/** A round outlined star on the picture: tap it to mark the wish as most wanted. */
@Composable
fun MarkMostWantedButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.size(34.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f))
            .semantics { contentDescription = "Mark as most wanted" }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        StarIcon(false, Color.White, 20.dp)
    }
}

/**
 * What sits in the top right corner of a large card for the star. For the owner ([onToggle] set) it is the label
 * when the wish is most wanted, or an outlined star to tap when it is not. Friends only ever see the label.
 * Wishes you already got show nothing.
 */
@Composable
fun StarCorner(w: Wish, onToggle: (() -> Unit)?) {
    if (!w.got) {
        if (w.star) MostWantedBadge(showLabel = true, onClick = onToggle)
        else if (onToggle != null) MarkMostWantedButton(onToggle)
    }
}
