package com.wishlist.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
private fun SectionTitle(t: String) {
    Text(
        t, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 20.dp)
    )
}

/**
 * The settings of the list that is open (the ⚙ in its top bar): name, note for friends, categories and sharing.
 * On a shared list also your name on that list and the manage buttons. Settings for the whole app are in [SettingsScreen].
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListSettingsScreen(snack: SnackbarHostState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val shared = Shared.current
    var name by remember { mutableStateOf(Repo.listName) }
    var about by remember { mutableStateOf(Repo.about) }
    var newCat by remember { mutableStateOf("") }
    var delCat by remember { mutableStateOf<String?>(null) }
    var renCat by remember { mutableStateOf<String?>(null) }
    var stopDlg by remember { mutableStateOf(false) }
    var manage by remember { mutableStateOf<String?>(null) }
    var meDlg by remember { mutableStateOf(false) }
    BackHandler(onBack = onBack)

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(Repo.listName, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (shared != null) "Shared wishlist settings" else "Wishlist settings",
                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background)
            )
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SectionTitle("Name of the wishlist")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(name, { name = it }, singleLine = true, modifier = Modifier.weight(1f))
                Button(onClick = {
                    Repo.setListName(ctx, name)
                    name = Repo.listName
                    scope.launch { snack.showSnackbar("Name saved") }
                }) { Text("Save") }
            }
            if (shared != null) {
                Text("Everyone on this list sees the new name.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)

                SectionTitle("Your name on this list")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(shared.me.ifBlank { Shared.lastName.ifBlank { "No name yet" } }, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            if (shared.me.isBlank() || shared.me == Shared.lastName) "From Settings. Shown as “Added by” on the wishes you add."
                            else "Only on this list. Settings has “${Shared.lastName}”.",
                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = { meDlg = true }) { Text("Use another name") }
                }
            }

            SectionTitle("Note for friends")
            Text(
                if (shared != null) "Shown at the top of the list. For example sizes, or things the person already has."
                else "Shown at the top of your shared list. For example your sizes, or things you don’t want.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
            OutlinedTextField(
                about, { about = it.take(ABOUT_MAX) }, maxLines = 5, modifier = Modifier.fillMaxWidth(),
                supportingText = { Text("${about.length}/$ABOUT_MAX") }
            )
            Button(onClick = {
                Repo.setAbout(ctx, about)
                about = Repo.about
                scope.launch { snack.showSnackbar("Note saved") }
            }) { Text("Save note") }

            SectionTitle("Categories")
            if (Repo.cats.isEmpty()) {
                Text("No categories yet.", color = cs.onSurfaceVariant)
            }
            Repo.cats.forEach { c ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(c, Modifier.weight(1f))
                    IconButton(onClick = { renCat = c }) {
                        Icon(Icons.Default.Edit, "Edit $c", tint = cs.onSurfaceVariant)
                    }
                    IconButton(onClick = { delCat = c }) {
                        Icon(Icons.Default.Delete, "Remove $c", tint = cs.onSurfaceVariant)
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    newCat, { newCat = it }, label = { Text("New category") },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
                Button(onClick = { Repo.addCat(ctx, newCat); newCat = "" }) { Text("Add") }
            }

            if (shared != null) {
                val title = Repo.listName
                val invite = inviteLink(shared.key)
                val friends = sharedListLink(shared.code)
                SectionTitle("Invite to edit")
                Text(
                    "They can add and change wishes and reserve gifts. Only send it to people you trust.",
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { scope.launch { ShareCard.share(ctx, ShareCard.Kind.INVITE, title, invite) } }) { Text("Send invite") }
                    OutlinedButton(onClick = {
                        clip.setText(AnnotatedString(invite))
                        scope.launch { snack.showSnackbar("Invite link copied") }
                    }) { Text("Copy link") }
                }
                SectionTitle("Link for givers who don’t edit")
                Text(
                    "They can only look and reserve a gift. Everyone on this list sees what’s reserved.",
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { scope.launch { ShareCard.share(ctx, ShareCard.Kind.FRIENDS, title, friends) } }) { Text("Send link") }
                    OutlinedButton(onClick = {
                        clip.setText(AnnotatedString(friends))
                        scope.launch { snack.showSnackbar("Link copied") }
                    }) { Text("Copy link") }
                }
                SectionTitle("Manage")
                if (shared.owner.isNotEmpty()) {
                    TextButton(onClick = { manage = "reset" }) { Text("Make a new invite link") }
                }
                TextButton(onClick = { manage = "leave" }) { Text("Leave this wishlist") }
                if (shared.owner.isNotEmpty()) {
                    TextButton(onClick = { manage = "delete" }) { Text("Delete for everyone", color = cs.error) }
                }
            } else {
                SectionTitle("Sharing")
                val code = Repo.shareCode
                if (!Config.enabled) {
                    Text("Online sharing isn’t set up in this build yet.", color = cs.onSurfaceVariant)
                } else if (code == null) {
                    Text(
                        "Not shared yet. Share your list so friends can reserve gifts. You won’t see what they reserve.",
                        color = cs.onSurfaceVariant
                    )
                    Button(onClick = { startShare(ctx, scope, snack) }) { Text("Share my wishlist") }
                } else {
                    Text("Friends open this link and tap Reserve. You never see what they reserve.", color = cs.onSurfaceVariant)
                    Text(shareLink(code), color = cs.onSurface)
                    if (Sync.photoStatus.isNotEmpty()) {
                        Text(Sync.photoStatus, color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        "Don’t open your own link in a browser, or you’ll see what’s reserved.",
                        color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { startShare(ctx, scope, snack) }) { Text("Share link") }
                        OutlinedButton(onClick = {
                            clip.setText(AnnotatedString(shareLink(code)))
                            scope.launch { snack.showSnackbar("Link copied") }
                        }) { Text("Copy link") }
                    }
                }
                TextButton(onClick = { shareList(ctx, Repo.wishes) }) { Text("Export as plain text") }
                if (Config.enabled && code != null) {
                    TextButton(onClick = { stopDlg = true }) { Text("Stop sharing", color = cs.error) }
                }
            }
        }
    }

    delCat?.let { dc -> DeleteCategoryDialog(dc, onDeleted = {}, onClose = { delCat = null }) }
    renCat?.let { rc -> RenameCategoryDialog(rc, onRenamed = {}, onClose = { renCat = null }) }
    manage?.let { m -> SharedManageDialog(m, onClose = { manage = null }, onGone = { manage = null; onBack() }) }
    if (meDlg && shared != null) {
        var n by remember { mutableStateOf(shared.me.ifBlank { Shared.lastName }) }
        AlertDialog(
            onDismissRequest = { meDlg = false },
            title = { Text("Your name on this list") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Only for “${Repo.listName}”. Leave it empty to use the name from Settings.",
                        style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant
                    )
                    OutlinedTextField(n, { n = it.take(30) }, singleLine = true, label = { Text("Your name") })
                }
            },
            confirmButton = {
                TextButton(onClick = { Shared.setMe(ctx, shared.code, n); meDlg = false }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { meDlg = false }) { Text("Cancel") } }
        )
    }
    if (stopDlg) {
        AlertDialog(
            onDismissRequest = { stopDlg = false },
            title = { Text("Stop sharing?") },
            text = { Text("The link stops working and all reservations are deleted. Sharing again later creates a new link.") },
            confirmButton = {
                TextButton(onClick = {
                    stopDlg = false
                    scope.launch {
                        try {
                            Sync.unpublish(ctx)
                        } catch (e: Exception) {
                            snack.showSnackbar("Couldn’t stop sharing. Check your connection.")
                        }
                    }
                }) { Text("Stop sharing") }
            },
            dismissButton = { TextButton(onClick = { stopDlg = false }) { Text("Cancel") } }
        )
    }
}
