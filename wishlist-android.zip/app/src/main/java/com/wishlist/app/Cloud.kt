package com.wishlist.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class CloudException(message: String) : Exception(message)

data class RemoteList(val name: String, val cats: List<String>, val wishes: List<Wish>)

/** Talks to the Supabase functions created by supabase-setup.sql. */
object Cloud {
    private suspend fun rpc(fn: String, body: JSONObject): String = withContext(Dispatchers.IO) {
        if (!Config.enabled) throw CloudException("Online sharing isn’t set up in this build.")
        val conn = URL(Config.SUPABASE_URL.trimEnd('/') + "/rest/v1/rpc/" + fn)
            .openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("apikey", Config.SUPABASE_KEY)
            // Old-style anon keys are JWTs and also go in Authorization. New publishable keys only need apikey.
            if (Config.SUPABASE_KEY.startsWith("eyJ")) {
                conn.setRequestProperty("Authorization", "Bearer " + Config.SUPABASE_KEY)
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val status = conn.responseCode
            val stream = if (status in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) throw CloudException("Server said $status: ${text.take(160)}")
            text
        } finally {
            conn.disconnect()
        }
    }

    private fun storageUrl(path: String) = Config.SUPABASE_URL.trimEnd('/') + "/storage/v1/object/" + path

    /** The address friends' browsers load a shared picture from. */
    fun photoUrl(code: String, name: String) = storageUrl("public/" + Config.PHOTO_BUCKET + "/" + code + "/" + name)

    private fun addKeys(conn: HttpURLConnection, ownerToken: String) {
        conn.setRequestProperty("apikey", Config.SUPABASE_KEY)
        if (Config.SUPABASE_KEY.startsWith("eyJ")) conn.setRequestProperty("Authorization", "Bearer " + Config.SUPABASE_KEY)
        // Proves to Supabase that this phone owns the list. Only the owner may add or remove its pictures.
        conn.setRequestProperty("x-owner-token", ownerToken)
    }

    suspend fun uploadPhoto(code: String, token: String, name: String, bytes: ByteArray) = withContext(Dispatchers.IO) {
        if (!Config.enabled) throw CloudException("Online sharing isn’t set up in this build.")
        val conn = URL(storageUrl(Config.PHOTO_BUCKET + "/" + code + "/" + name)).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.doOutput = true
            conn.setFixedLengthStreamingMode(bytes.size)
            conn.setRequestProperty("Content-Type", "image/jpeg")
            conn.setRequestProperty("Cache-Control", "max-age=31536000")
            addKeys(conn, token)
            conn.outputStream.use { it.write(bytes) }
            val status = conn.responseCode
            val text = (if (status in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            // "Duplicate" means this exact picture is already there, which is fine.
            if (status !in 200..299 && !text.contains("Duplicate")) {
                throw CloudException("Photo upload said $status: ${text.take(120)}")
            }
        } finally {
            conn.disconnect()
        }
    }

    suspend fun deletePhoto(code: String, token: String, name: String) = withContext(Dispatchers.IO) {
        if (!Config.enabled) throw CloudException("Online sharing isn’t set up in this build.")
        val conn = URL(storageUrl(Config.PHOTO_BUCKET + "/" + code + "/" + name)).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "DELETE"
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            addKeys(conn, token)
            val status = conn.responseCode
            val text = (if (status in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            // 404 means it is already gone, which is what we wanted.
            if (status !in 200..299 && status != 404) {
                throw CloudException("Photo delete said $status: ${text.take(120)}")
            }
        } finally {
            conn.disconnect()
        }
    }

    suspend fun createList(code: String, token: String, name: String) {
        rpc("wl_create_list", JSONObject().put("p_code", code).put("p_token", token).put("p_name", name))
    }

    suspend fun pushList(code: String, token: String, name: String, cats: List<String>, wishes: List<Wish>) {
        val items = JSONArray()
        wishes.forEach { items.put(wishToJson(if (ImageStore.isLocal(it.image)) it.copy(image = "") else it)) }
        rpc(
            "wl_sync_list",
            JSONObject()
                .put("p_code", code).put("p_token", token).put("p_name", name)
                .put("p_cats", JSONArray(cats)).put("p_items", items)
        )
    }

    suspend fun deleteList(code: String, token: String) {
        rpc("wl_delete_list", JSONObject().put("p_code", code).put("p_token", token))
    }

    /** Returns null when no list exists for that code. */
    suspend fun fetchList(code: String): RemoteList? {
        val t = rpc("wl_get_list", JSONObject().put("p_code", code)).trim()
        if (t.isEmpty() || t == "null") return null
        val o = JSONObject(t)
        val a = o.getJSONArray("items")
        val cs = o.optJSONArray("cats")
        return RemoteList(
            o.optString("name", "Wishlist"),
            if (cs == null) emptyList() else (0 until cs.length()).map { cs.getString(it) },
            (0 until a.length()).map { wishFromJson(a.getJSONObject(it)) }
        )
    }

    /** Item id -> true if reserved by this phone, false if reserved by someone else. */
    suspend fun fetchReservations(code: String, device: String): Map<Long, Boolean> {
        val t = rpc("wl_get_reservations", JSONObject().put("p_code", code).put("p_device", device))
        val a = JSONArray(t)
        val m = HashMap<Long, Boolean>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            m[o.getLong("id")] = o.getBoolean("mine")
        }
        return m
    }

    /** False if somebody else got there first. */
    suspend fun reserve(code: String, item: Long, device: String): Boolean =
        rpc(
            "wl_reserve_item",
            JSONObject().put("p_code", code).put("p_item", item).put("p_device", device)
        ).trim() == "true"

    suspend fun unreserve(code: String, item: Long, device: String) {
        rpc(
            "wl_unreserve_item",
            JSONObject().put("p_code", code).put("p_item", item).put("p_device", device)
        )
    }
}
