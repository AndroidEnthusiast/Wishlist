package com.wishlist.app

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.core.view.WindowCompat

@OptIn(ExperimentalTextApi::class)
val GoogleSans = FontFamily(
    Font(R.font.google_sans, FontWeight.Normal, variationSettings = FontVariation.Settings(FontVariation.weight(400))),
    Font(R.font.google_sans, FontWeight.Medium, variationSettings = FontVariation.Settings(FontVariation.weight(500))),
    Font(R.font.google_sans, FontWeight.SemiBold, variationSettings = FontVariation.Settings(FontVariation.weight(600))),
    Font(R.font.google_sans, FontWeight.Bold, variationSettings = FontVariation.Settings(FontVariation.weight(700)))
)

private fun typo(): Typography {
    val d = Typography()
    val f = GoogleSans
    return Typography(
        displayLarge = d.displayLarge.copy(fontFamily = f), displayMedium = d.displayMedium.copy(fontFamily = f),
        displaySmall = d.displaySmall.copy(fontFamily = f), headlineLarge = d.headlineLarge.copy(fontFamily = f),
        headlineMedium = d.headlineMedium.copy(fontFamily = f), headlineSmall = d.headlineSmall.copy(fontFamily = f),
        titleLarge = d.titleLarge.copy(fontFamily = f), titleMedium = d.titleMedium.copy(fontFamily = f),
        titleSmall = d.titleSmall.copy(fontFamily = f), bodyLarge = d.bodyLarge.copy(fontFamily = f),
        bodyMedium = d.bodyMedium.copy(fontFamily = f), bodySmall = d.bodySmall.copy(fontFamily = f),
        labelLarge = d.labelLarge.copy(fontFamily = f), labelMedium = d.labelMedium.copy(fontFamily = f),
        labelSmall = d.labelSmall.copy(fontFamily = f)
    )
}

private val Light = lightColorScheme(
    primary = Color(0xFF4355B9), onPrimary = Color.White,
    primaryContainer = Color(0xFFDEE0FF), onPrimaryContainer = Color(0xFF00105C),
    secondaryContainer = Color(0xFFDEE0FF), onSecondaryContainer = Color(0xFF00105C),
    background = Color(0xFFFBF8FF), onBackground = Color(0xFF1B1B21),
    surface = Color(0xFFFBF8FF), onSurface = Color(0xFF1B1B21),
    surfaceVariant = Color(0xFFF0EDF7), onSurfaceVariant = Color(0xFF46464F),
    outline = Color(0xFF777680)
)
private val Dark = darkColorScheme(
    primary = Color(0xFFBAC3FF), onPrimary = Color(0xFF08218A),
    primaryContainer = Color(0xFF2C3FA0), onPrimaryContainer = Color(0xFFDEE0FF),
    secondaryContainer = Color(0xFF2C3FA0), onSecondaryContainer = Color(0xFFDEE0FF),
    background = Color(0xFF121318), onBackground = Color(0xFFE4E1E9),
    surface = Color(0xFF121318), onSurface = Color(0xFFE4E1E9),
    surfaceVariant = Color(0xFF1F1F25), onSurfaceVariant = Color(0xFFC7C5D0),
    outline = Color(0xFF91909A)
)
private val Amoled = Dark.copy(
    background = Color.Black, surface = Color.Black, surfaceVariant = Color(0xFF0E0E11)
)

@Composable
fun isDarkMode(): Boolean {
    val sys = isSystemInDarkTheme()
    return when (Repo.theme) { "light" -> false; "dark", "amoled" -> true; else -> sys }
}

/** The theme actually in use: "light", "dark" or "amoled". */
@Composable
fun effectiveTheme(): String {
    val sys = isSystemInDarkTheme()
    return if (Repo.theme == "system") (if (sys) "dark" else "light") else Repo.theme
}

@Composable
fun WishTheme(content: @Composable () -> Unit) {
    val mode = effectiveTheme()
    val scheme = when (mode) { "amoled" -> Amoled; "dark" -> Dark; else -> Light }
    val view = LocalView.current
    SideEffect {
        (view.context as? Activity)?.window?.let { w ->
            w.statusBarColor = scheme.background.toArgb()
            w.navigationBarColor = scheme.background.toArgb()
            WindowCompat.getInsetsController(w, view).apply {
                isAppearanceLightStatusBars = mode == "light"
                isAppearanceLightNavigationBars = mode == "light"
            }
        }
    }
    MaterialTheme(colorScheme = scheme, typography = typo(), content = content)
}
