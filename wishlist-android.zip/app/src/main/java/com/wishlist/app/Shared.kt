package com.wishlist.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger

/** A wishlist you edit together with other people. [owner] is only filled on the phone that created it. */
data class SharedList(
    /** The list's public code. Friends use it in their link. */
    val code: String,
    /** The secret edit key from the invite link. Whoever has it can edit. */
    val key: String,
    val name: String,
    /** The creator's owner token (empty on phones that joined). Needed to reset the invite link or delete the list. */
    val owner: String = "",
    /** The name you use on this list ("Added by ..."). */
    val me: String = ""
)

/** What is shown of the shared wishlist that is open. */
data class SharedContent(
    val name: String = "",
    val cats: List<String> = emptyList(),
    val about: String = "",
    val wishes: List<Wish> = emptyList()
)

/**
 * Wishlists you edit together with others. The online copy is the truth: every change is sent as one wish
 * (never the whole list), and the screen refreshes from the online copy every few seconds. Editing needs
 * internet; the last copy is kept on the phone so you can still look at the list offline.
 */
object Shared {
    var lists by mutableStateOf(listOf<SharedList>())
        private set

    /** Code of the shared wishlist that is open on screen, or null when My wishlist is. */
    var active by mutableStateOf<String?>(null)
        private set
    var content by mutableStateOf(SharedContent())
        private set

    /** True when the open list can't be reached with our key anymore (deleted, or the invite link was reset). */
    var gone by mutableStateOf(false)
        private set

    /** A short message for the snackbar (for example "Couldn't save that"). Cleared once shown. */
    var notice by mutableStateOf("")
        private set

    /** The name typed last time, to prefill the "your name" fields. */
    var lastName by mutableStateOf("")
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Mutex()
    private val pending = AtomicInteger(0)

    val current: SharedList? get() = lists.firstOrNull { it.code == active }
    val me: String get() = current?.me.orEmpty()
    val isCreator: Boolean get() = current?.owner?.isNotEmpty() == true

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("wishlist", Context.MODE_PRIVATE)

    fun load(c: Context) {
        val p = prefs(c)
        lastName = p.getString("sh_me", "") ?: ""
        lists = try {
            val a = JSONArray(p.getString("shared", null) ?: "[]")
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                SharedList(
                    o.getString("code"), o.getString("key"), o.optString("name", "Shared wishlist"),
                    o.optString("owner", ""), o.optString("me", "")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
        active = null
        gone = false
    }

    private fun saveLists(c: Context) {
        val a = JSONArray()
        lists.forEach {
            a.put(
                JSONObject().put("code", it.code).put("key", it.key).put("name", it.name)
                    .put("owner", it.owner).put("me", it.me)
            )
        }
        prefs(c).edit().putString("shared", a.toString()).apply()
    }

    private fun rememberName(c: Context, name: String) {
        if (name.isBlank()) return
        lastName = name
        prefs(c).edit().putString("sh_me", name).apply()
    }

    // ---- the copy kept on the phone, for looking at a list without internet ----

    private fun cacheKey(code: String) = "shc_$code"

    private fun readCache(c: Context, code: String): SharedContent? {
        val s = prefs(c).getString(cacheKey(code), null) ?: return null
        return try {
            val o = JSONObject(s)
            val cs = o.optJSONArray("cats")
            val items = o.optJSONArray("items")
            SharedContent(
                o.optString("name", ""),
                if (cs == null) emptyList() else (0 until cs.length()).map { cs.getString(it) },
                o.optString("about", ""),
                if (items == null) emptyList() else (0 until items.length()).map { wishFromJson(items.getJSONObject(it)) }
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun writeCache(c: Context, code: String, ct: SharedContent) {
        val items = JSONArray()
        ct.wishes.forEach { items.put(wishToJson(it)) }
        val o = JSONObject().put("name", ct.name).put("cats", JSONArray(ct.cats))
            .put("about", ct.about).put("items", items)
        prefs(c).edit().putString(cacheKey(code), o.toString()).apply()
    }

    // ---- opening and refreshing ----

    fun open(c: Context, code: String) {
        val l = lists.firstOrNull { it.code == code } ?: return
        content = readCache(c, code) ?: SharedContent(name = l.name)
        gone = false
        active = code
    }

    fun close() {
        active = null
        gone = false
    }

    fun clearNotice() {
        notice = ""
    }

    /** Fetches the online copy of the open list. Returns false when the server couldn't be reached (the screen keeps what it has). */
    suspend fun refresh(c: Context): Boolean {
        val l = current ?: return true
        if (pending.get() > 0) return true
        val r = try {
            Cloud.shGet(l.key)
        } catch (e: Exception) {
            return false
        }
        // The user may have switched lists, or started editing, while we were waiting.
        if (active != l.code || pending.get() > 0) return true
        if (r == null) {
            gone = true
            return true
        }
        gone = false
        val nc = SharedContent(r.list.name, r.list.cats, r.list.about, r.list.wishes)
        if (nc != content) content = nc
        writeCache(c, l.code, nc)
        if (r.list.name != l.name) {
            lists = lists.map { if (it.code == l.code) it.copy(name = r.list.name) else it }
            saveLists(c)
        }
        return true
    }

    // ---- changing the open list: shown at once, saved online one wish at a time, undone if saving fails ----

    private fun write(c: Context, l: SharedList, before: SharedContent, after: SharedContent, job: suspend () -> Unit) {
        content = after
        pending.incrementAndGet()
        scope.launch {
            var ok = false
            try {
                lock.withLock { job() }
                ok = true
            } catch (e: Exception) {
                notice = "Couldn’t save that. Check your connection and try again."
            } finally {
                pending.decrementAndGet()
            }
            if (ok) {
                if (active == l.code) writeCache(c, l.code, content)
            } else if (active == l.code) {
                // Nothing else changed in the meantime: go back to how it was. Otherwise ask the server what is true.
                if (content === after) content = before else { refresh(c) }
            }
        }
    }

    private fun photoNameOf(code: String, url: String): String? {
        val prefix = Cloud.photoUrl(code, "")
        if (!url.startsWith(prefix)) return null
        return url.removePrefix(prefix).takeIf { it.isNotEmpty() && !it.contains('/') }
    }

    private suspend fun dropPhoto(l: SharedList, url: String) {
        val n = photoNameOf(l.code, url) ?: return
        try {
            Cloud.deletePhoto(l.code, l.key, n, "x-edit-key")
        } catch (e: Exception) {
        }
    }

    /** Adds a wish, or saves a changed one. A picture picked on this phone is uploaded first. */
    fun put(c: Context, w: Wish) {
        val l = current ?: return
        val before = content
        val old = before.wishes.firstOrNull { it.id == w.id }
        val mine = if (old == null && w.by.isBlank()) w.copy(by = l.me) else w
        val after = before.copy(
            wishes = if (old != null) before.wishes.map { if (it.id == w.id) mine else it } else listOf(mine) + before.wishes
        )
        write(c, l, before, after) {
            var out = mine
            if (ImageStore.isLocal(out.image)) {
                val name = out.image.substringAfterLast('/')
                val bytes = ImageStore.shareCopy(out.image)
                out = if (bytes != null) {
                    try {
                        Cloud.uploadPhoto(l.code, l.key, name, bytes, "x-edit-key")
                        out.copy(image = Cloud.photoUrl(l.code, name))
                    } catch (e: Exception) {
                        notice = "Saved without the picture: it couldn’t be uploaded."
                        out.copy(image = "")
                    }
                } else out.copy(image = "")
            }
            Cloud.shPut(l.key, out)
            if (out.image != mine.image) {
                // The picture now lives online. Show that one here too and free the copy on this phone.
                ImageStore.delete(c, mine.image)
                if (active == l.code) {
                    content = content.copy(
                        wishes = content.wishes.map { if (it.id == out.id && it.image == mine.image) out else it }
                    )
                }
            }
            // A picture that was replaced or removed is deleted online too.
            if (old != null && old.image != out.image) dropPhoto(l, old.image)
        }
    }

    fun delete(c: Context, id: Long) {
        val l = current ?: return
        val before = content
        val removed = before.wishes.firstOrNull { it.id == id } ?: return
        val after = before.copy(wishes = before.wishes.filter { it.id != id })
        write(c, l, before, after) {
            Cloud.shDelete(l.key, id)
            ImageStore.delete(c, removed.image)
            dropPhoto(l, removed.image)
        }
    }

    fun setName(c: Context, name: String) {
        val l = current ?: return
        val before = content
        val after = before.copy(name = name)
        lists = lists.map { if (it.code == l.code) it.copy(name = name) else it }
        saveLists(c)
        write(c, l, before, after) { Cloud.shMeta(l.key, after.name, after.cats, after.about) }
    }

    fun setAbout(c: Context, about: String) {
        val l = current ?: return
        val before = content
        val after = before.copy(about = about)
        write(c, l, before, after) { Cloud.shMeta(l.key, after.name, after.cats, after.about) }
    }

    /** [name] is already cleaned and known to be new (Repo.addCat checks that). */
    fun addCat(c: Context, name: String): String? {
        val l = current ?: return null
        val before = content
        val after = before.copy(cats = before.cats + name)
        write(c, l, before, after) { Cloud.shMeta(l.key, after.name, after.cats, after.about) }
        return name
    }

    fun renameCat(c: Context, old: String, name: String): Boolean {
        val l = current ?: return false
        val before = content
        val moved = before.wishes.filter { it.category == old }.map { it.copy(category = name) }
        val after = before.copy(
            cats = before.cats.map { if (it == old) name else it },
            wishes = before.wishes.map { if (it.category == old) it.copy(category = name) else it }
        )
        write(c, l, before, after) {
            Cloud.shMeta(l.key, after.name, after.cats, after.about)
            moved.forEach { Cloud.shPut(l.key, it) }
        }
        return true
    }

    fun removeCat(c: Context, name: String) {
        val l = current ?: return
        val before = content
        val moved = before.wishes.filter { it.category == name }.map { it.copy(category = "") }
        val after = before.copy(
            cats = before.cats.filter { it != name },
            wishes = before.wishes.map { if (it.category == name) it.copy(category = "") else it }
        )
        write(c, l, before, after) {
            Cloud.shMeta(l.key, after.name, after.cats, after.about)
            moved.forEach { Cloud.shPut(l.key, it) }
        }
    }

    // ---- making, joining and leaving lists ----

    /** Makes a new shared wishlist online and adds it to this phone. */
    suspend fun create(c: Context, name: String, me: String): SharedList {
        val n = name.trim().ifEmpty { "Our wishlist" }
        val code = Sync.newCode()
        val key = Sync.newKey()
        val token = Sync.newKey()
        Cloud.shCreate(code, key, token, n)
        val l = SharedList(code, key, n, token, me.trim())
        rememberName(c, l.me)
        lists = lists + l
        saveLists(c)
        return l
    }

    /** Accepts an invite. Returns the list, or null when the invite doesn't work (anymore). */
    suspend fun join(c: Context, key: String, me: String): SharedList? {
        val r = Cloud.shGet(key) ?: return null
        val name = me.trim()
        rememberName(c, name)
        val old = lists.firstOrNull { it.code == r.code }
        val l = if (old != null) {
            // Already on this list (for example after the invite link was reset): just take the new key.
            old.copy(key = key, name = r.list.name, me = name.ifEmpty { old.me })
        } else {
            SharedList(r.code, key, r.list.name, "", name)
        }
        lists = if (old != null) lists.map { if (it.code == r.code) l else it } else lists + l
        saveLists(c)
        writeCache(c, r.code, SharedContent(r.list.name, r.list.cats, r.list.about, r.list.wishes))
        return l
    }

    /** Takes the list off this phone only. It stays online for everyone else. */
    fun leave(c: Context, code: String) {
        if (active == code) close()
        lists = lists.filter { it.code != code }
        saveLists(c)
        prefs(c).edit().remove(cacheKey(code)).apply()
    }

    /** Creator only: deletes the list online for everyone (wishes, reservations, pictures). */
    suspend fun deleteForEveryone(c: Context) {
        val l = current ?: return
        if (l.owner.isEmpty()) throw CloudException("Only the person who made this list can delete it.")
        content.wishes.forEach { dropPhoto(l, it.image) }
        Cloud.deleteList(l.code, l.owner)
        leave(c, l.code)
    }

    /** Creator only: a new edit key. The old invite link stops working. Returns the new key. */
    suspend fun resetKey(c: Context): String {
        val l = current ?: throw CloudException("No shared wishlist is open.")
        if (l.owner.isEmpty()) throw CloudException("Only the person who made this list can do that.")
        val nk = Sync.newKey()
        Cloud.shReset(l.code, l.owner, nk)
        lists = lists.map { if (it.code == l.code) it.copy(key = nk) else it }
        saveLists(c)
        return nk
    }
}
