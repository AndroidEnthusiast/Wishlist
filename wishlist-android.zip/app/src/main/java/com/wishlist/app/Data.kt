package com.wishlist.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Currency
import java.util.UUID

data class Wish(
    val id: Long,
    val url: String,
    val title: String,
    val desc: String,
    val image: String,
    val price: Double?,
    val oldPrice: Double?,
    val currency: String,
    val category: String,
    val got: Boolean = false
)

/** A wishlist that someone else shared with you. */
data class Friend(val code: String, val name: String)

fun wishToJson(w: Wish): JSONObject = JSONObject().apply {
    put("id", w.id); put("url", w.url); put("title", w.title)
    put("desc", w.desc); put("image", w.image)
    put("price", w.price ?: JSONObject.NULL)
    put("old", w.oldPrice ?: JSONObject.NULL)
    put("cur", w.currency); put("cat", w.category); put("got", w.got)
}

fun wishFromJson(o: JSONObject): Wish = Wish(
    o.getLong("id"), o.getString("url"), o.getString("title"),
    o.optString("desc"), o.optString("image"),
    if (o.isNull("price")) null else o.getDouble("price"),
    if (o.isNull("old")) null else o.getDouble("old"),
    o.optString("cur", "USD"), o.optString("cat", ""), o.optBoolean("got")
)

object Repo {
    var wishes by mutableStateOf(listOf<Wish>())
        private set
    var cats by mutableStateOf(listOf("Tech", "Home", "Fashion", "Books"))
        private set
    var theme by mutableStateOf("system")
        private set
    var listName by mutableStateOf("My wishlist")
        private set

    /** Set once the owner has shared the list online. */
    var shareCode by mutableStateOf<String?>(null)
        private set
    var ownerToken: String? = null
        private set
    var friends by mutableStateOf(listOf<Friend>())
        private set
    var deviceId: String = ""
        private set
    private var loaded = false

    private fun prefs(c: Context) =
        c.applicationContext.getSharedPreferences("wishlist", Context.MODE_PRIVATE)

    @Synchronized
    fun load(c: Context) {
        if (loaded) return
        loaded = true
        val p = prefs(c)
        p.getString("wishes", null)?.let { s ->
            try {
                val a = JSONArray(s)
                wishes = (0 until a.length()).map { i -> wishFromJson(a.getJSONObject(i)) }
            } catch (e: Exception) {
            }
        }
        p.getString("cats", null)?.let { s ->
            cats = s.split("\n").filter { it.isNotBlank() }
        }
        theme = p.getString("theme", "system") ?: "system"
        listName = p.getString("name", null)?.takeIf { it.isNotBlank() } ?: "My wishlist"
        shareCode = p.getString("code", null)
        ownerToken = p.getString("token", null)
        p.getString("friends", null)?.let { s ->
            try {
                val a = JSONArray(s)
                friends = (0 until a.length()).map { i ->
                    val o = a.getJSONObject(i)
                    Friend(o.getString("code"), o.optString("name", "Wishlist"))
                }
            } catch (e: Exception) {
            }
        }
        deviceId = p.getString("device", null)
            ?: UUID.randomUUID().toString().also { p.edit().putString("device", it).apply() }
    }

    private fun persist(c: Context) {
        val arr = JSONArray()
        wishes.forEach { arr.put(wishToJson(it)) }
        val fr = JSONArray()
        friends.forEach { fr.put(JSONObject().put("code", it.code).put("name", it.name)) }
        prefs(c).edit()
            .putString("wishes", arr.toString())
            .putString("cats", cats.joinToString("\n"))
            .putString("theme", theme)
            .putString("name", listName)
            .putString("code", shareCode)
            .putString("token", ownerToken)
            .putString("friends", fr.toString())
            .apply()
    }

    /** Saves locally and, if the list is shared, pushes the change online. */
    private fun commit(c: Context) {
        persist(c)
        Sync.push()
    }

    @Synchronized
    fun add(c: Context, w: Wish) { wishes = listOf(w) + wishes; commit(c) }

    @Synchronized
    fun replace(c: Context, w: Wish) { wishes = wishes.map { if (it.id == w.id) w else it }; commit(c) }

    @Synchronized
    fun remove(c: Context, id: Long) { wishes = wishes.filter { it.id != id }; commit(c) }

    @Synchronized
    fun addCat(c: Context, name: String) {
        val n = name.trim()
        if (n.isNotEmpty() && n != "All" && n !in cats) { cats = cats + n; commit(c) }
    }

    /** Removes a category. Wishes that were in it stay, just without a category. */
    @Synchronized
    fun removeCat(c: Context, name: String) {
        cats = cats.filter { it != name }
        wishes = wishes.map { if (it.category == name) it.copy(category = "") else it }
        commit(c)
    }

    @Synchronized
    fun setListName(c: Context, name: String) {
        listName = name.trim().ifEmpty { "My wishlist" }
        commit(c)
    }

    @Synchronized
    fun setTheme(c: Context, t: String) { theme = t; persist(c) }

    @Synchronized
    fun setShare(c: Context, code: String?, token: String?) {
        shareCode = code; ownerToken = token; persist(c)
    }

    @Synchronized
    fun addFriend(c: Context, f: Friend) { friends = friends.filter { it.code != f.code } + f; persist(c) }

    @Synchronized
    fun removeFriend(c: Context, code: String) { friends = friends.filter { it.code != code }; persist(c) }

    @Synchronized
    fun renameFriend(c: Context, code: String, name: String) {
        friends = friends.map { if (it.code == code) it.copy(name = name) else it }; persist(c)
    }
}

fun money(p: Double, cur: String): String = try {
    NumberFormat.getCurrencyInstance().apply { currency = Currency.getInstance(cur) }.format(p)
} catch (e: Exception) {
    "%.2f".format(p)
}
