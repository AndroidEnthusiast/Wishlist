package com.wishlist.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Currency

data class Wish(
    val id: Long,
    val url: String,
    val title: String,
    val desc: String,
    val image: String,
    val price: Double?,
    val oldPrice: Double?,
    val currency: String,
    val category: String,
    val got: Boolean = false
)

object Repo {
    var wishes by mutableStateOf(listOf<Wish>())
        private set
    var cats by mutableStateOf(listOf("Tech", "Home", "Fashion", "Books"))
        private set
    var theme by mutableStateOf("system")
        private set
    private var loaded = false

    private fun prefs(c: Context) =
        c.applicationContext.getSharedPreferences("wishlist", Context.MODE_PRIVATE)

    @Synchronized
    fun load(c: Context) {
        if (loaded) return
        loaded = true
        val p = prefs(c)
        p.getString("wishes", null)?.let { s ->
            try {
                val a = JSONArray(s)
                wishes = (0 until a.length()).map { i ->
                    val o = a.getJSONObject(i)
                    Wish(
                        o.getLong("id"), o.getString("url"), o.getString("title"),
                        o.optString("desc"), o.optString("image"),
                        if (o.isNull("price")) null else o.getDouble("price"),
                        if (o.isNull("old")) null else o.getDouble("old"),
                        o.optString("cur", "USD"), o.optString("cat", "All"), o.optBoolean("got")
                    )
                }
            } catch (e: Exception) {
            }
        }
        p.getString("cats", null)?.let { s ->
            val l = s.split("\n").filter { it.isNotBlank() }
            if (l.isNotEmpty()) cats = l
        }
        theme = p.getString("theme", "system") ?: "system"
    }

    private fun persist(c: Context) {
        val arr = JSONArray()
        wishes.forEach { w ->
            arr.put(JSONObject().apply {
                put("id", w.id); put("url", w.url); put("title", w.title)
                put("desc", w.desc); put("image", w.image)
                put("price", w.price ?: JSONObject.NULL)
                put("old", w.oldPrice ?: JSONObject.NULL)
                put("cur", w.currency); put("cat", w.category); put("got", w.got)
            })
        }
        prefs(c).edit()
            .putString("wishes", arr.toString())
            .putString("cats", cats.joinToString("\n"))
            .putString("theme", theme)
            .apply()
    }

    @Synchronized
    fun add(c: Context, w: Wish) { wishes = listOf(w) + wishes; persist(c) }

    @Synchronized
    fun replace(c: Context, w: Wish) { wishes = wishes.map { if (it.id == w.id) w else it }; persist(c) }

    @Synchronized
    fun remove(c: Context, id: Long) { wishes = wishes.filter { it.id != id }; persist(c) }

    @Synchronized
    fun addCat(c: Context, name: String) {
        val n = name.trim()
        if (n.isNotEmpty() && n !in cats) { cats = cats + n; persist(c) }
    }

    @Synchronized
    fun setTheme(c: Context, t: String) { theme = t; persist(c) }
}

fun money(p: Double, cur: String): String = try {
    NumberFormat.getCurrencyInstance().apply { currency = Currency.getInstance(cur) }.format(p)
} catch (e: Exception) {
    "%.2f".format(p)
}
