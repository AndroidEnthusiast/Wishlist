package com.wishlist.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup

data class Meta(val title: String, val desc: String, val image: String, val price: Double?, val currency: String)

private const val UA =
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

/** Pulls the first link out of shared text, or turns "store.com/item" into a full URL. */
fun cleanUrl(s: String): String? {
    Regex("https?://\\S+").find(s)?.let { return it.value }
    val t = s.trim()
    return if (t.contains('.') && !t.contains(' ')) "https://$t" else null
}

private fun String.toNum(): Double? {
    val s = replace(Regex("[^0-9.,]"), "")
    if (s.isEmpty()) return null
    val n = when {
        s.contains(',') && s.contains('.') ->
            if (s.lastIndexOf(',') > s.lastIndexOf('.')) s.replace(".", "").replace(',', '.') else s.replace(",", "")
        s.contains(',') ->
            if (s.length - s.lastIndexOf(',') == 3) s.replace(',', '.') else s.replace(",", "")
        else -> s
    }
    return n.toDoubleOrNull()
}

/** Reads title, image, description and price from a product page's meta tags and JSON-LD. */
suspend fun fetchMeta(url: String): Meta? = withContext(Dispatchers.IO) {
    try {
        val d = Jsoup.connect(url).userAgent(UA).timeout(12000).followRedirects(true).get()
        fun m(vararg keys: String): String {
            for (k in keys) {
                val v = d.selectFirst("meta[property=\"$k\"], meta[name=\"$k\"], meta[itemprop=\"$k\"]")
                    ?.attr("content")?.trim().orEmpty()
                if (v.isNotEmpty()) return v
            }
            return ""
        }
        val title = m("og:title", "twitter:title").ifEmpty { d.title() }
        val image = d.selectFirst("meta[property=\"og:image\"], meta[name=\"twitter:image\"]")
            ?.absUrl("content").orEmpty()
        var price = m("product:price:amount", "og:price:amount", "price").toNum()
        var cur = m("product:price:currency", "og:price:currency", "priceCurrency")
        if (price == null) {
            val ld = d.select("script[type=application/ld+json]").joinToString(" ") { it.data() }
            price = Regex("\"price\"\\s*:\\s*\"?([0-9][0-9.,]*)").find(ld)?.groupValues?.get(1)?.toNum()
            if (cur.isEmpty()) {
                cur = Regex("\"priceCurrency\"\\s*:\\s*\"([A-Z]{3})\"").find(ld)?.groupValues?.get(1).orEmpty()
            }
        }
        if (title.isBlank()) null
        else Meta(
            title.take(120),
            m("og:description", "twitter:description", "description").take(200),
            image, price, cur.ifEmpty { "USD" }
        )
    } catch (e: Exception) {
        null
    }
}
