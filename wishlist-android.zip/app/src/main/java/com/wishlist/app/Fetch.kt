package com.wishlist.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup

data class Meta(
    val title: String,
    val desc: String,
    val image: String,
    val price: Double?,
    val currency: String,
    val blocked: Boolean = false
)

private const val UA =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

/** Pulls the first link out of shared text, or turns "store.com/item" into a full URL. */
fun cleanUrl(s: String): String? {
    val raw = Regex("https?://\\S+").find(s)?.value
        ?: s.trim().takeIf { it.contains('.') && !it.contains(' ') }?.let { "https://$it" }
        ?: return null
    return amazonCanonical(raw)
}

/** Trims Amazon links to https://host/dp/ASIN so tracking junk never breaks price checks. */
private fun amazonCanonical(u: String): String {
    val host = Regex("https?://([^/?#]+)").find(u)?.groupValues?.get(1) ?: return u
    if (!host.contains("amazon.")) return u
    val asin = Regex("/(?:dp|gp/product|gp/aw/d)/([A-Z0-9]{10})").find(u)?.groupValues?.get(1) ?: return u
    return "https://$host/dp/$asin"
}

private fun String.toNum(): Double? {
    val s = replace(Regex("[^0-9.,]"), "")
    if (s.isEmpty()) return null
    val n = when {
        s.contains(',') && s.contains('.') ->
            if (s.lastIndexOf(',') > s.lastIndexOf('.')) s.replace(".", "").replace(',', '.') else s.replace(",", "")
        s.contains(',') ->
            if (s.length - s.lastIndexOf(',') == 3) s.replace(',', '.') else s.replace(",", "")
        else -> s
    }
    return n.toDoubleOrNull()
}

private fun currencyOf(text: String, host: String): String = when {
    text.contains("£") || host.endsWith(".co.uk") -> "GBP"
    text.contains("€") || host.endsWith(".de") || host.endsWith(".fr") ||
        host.endsWith(".it") || host.endsWith(".es") || host.endsWith(".nl") -> "EUR"
    text.contains("₹") || host.endsWith(".in") -> "INR"
    text.contains("¥") || host.endsWith(".co.jp") -> "JPY"
    host.endsWith(".ca") -> "CAD"
    host.endsWith(".com.au") -> "AUD"
    host.endsWith(".com.mx") -> "MXN"
    else -> "USD"
}

private val AMAZON_PRICE = listOf(
    "#corePriceDisplay_desktop_feature_div .priceToPay .a-offscreen",
    "#corePrice_feature_div .priceToPay .a-offscreen",
    "#corePriceDisplay_desktop_feature_div .a-price:not(.a-text-price) .a-offscreen",
    "#corePrice_feature_div .a-price:not(.a-text-price) .a-offscreen",
    "#apex_desktop .a-price:not(.a-text-price) .a-offscreen",
    "#priceblock_dealprice", "#priceblock_ourprice", "#price_inside_buy",
    "#tp_price_block_total_price_ww .a-offscreen",
    ".a-price:not(.a-text-price) .a-offscreen"
)

/** Reads title, image, description and price from a product page. Returns blocked=true if the store refused. */
suspend fun fetchMeta(url: String): Meta? = withContext(Dispatchers.IO) {
    try {
        val res = Jsoup.connect(url).userAgent(UA)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9")
            .timeout(15000).followRedirects(true).ignoreHttpErrors(true).execute()
        val d = res.parse()
        val host = res.url().host.orEmpty()
        val isAmazon = host.contains("amazon.")
        val blocked = res.statusCode() in listOf(403, 429, 503) ||
            d.selectFirst("form[action*=validateCaptcha]") != null ||
            d.title().contains("Robot Check", true)
        if (blocked) return@withContext Meta("", "", "", null, "USD", true)

        fun m(vararg keys: String): String {
            for (k in keys) {
                val v = d.selectFirst("meta[property=\"$k\"], meta[name=\"$k\"], meta[itemprop=\"$k\"]")
                    ?.attr("content")?.trim().orEmpty()
                if (v.isNotEmpty()) return v
            }
            return ""
        }

        var title = m("og:title", "twitter:title").ifEmpty { d.title() }
        if (isAmazon) {
            title = title.replace(Regex("^Amazon\\.[a-z.]+\\s*:\\s*"), "").replace(Regex("\\s+:\\s+[^:]+$"), "")
        }
        var image = d.selectFirst("meta[property=\"og:image\"], meta[name=\"twitter:image\"]")
            ?.absUrl("content").orEmpty()
        if (image.isEmpty() && isAmazon) {
            image = d.selectFirst("#landingImage, #imgBlkFront")?.let {
                it.attr("data-old-hires").ifEmpty { it.absUrl("src") }
            }.orEmpty()
        }

        var price = m("product:price:amount", "og:price:amount", "price").toNum()
        var cur = m("product:price:currency", "og:price:currency", "priceCurrency")
        if (price == null && isAmazon) {
            for (sel in AMAZON_PRICE) {
                val t = d.selectFirst(sel)?.text().orEmpty()
                val n = t.toNum()
                if (n != null && n > 0) { price = n; cur = currencyOf(t, host); break }
            }
        }
        if (price == null) {
            val ld = d.select("script[type=application/ld+json]").joinToString(" ") { it.data() }
            price = Regex("\"price\"\\s*:\\s*\"?([0-9][0-9.,]*)").find(ld)?.groupValues?.get(1)?.toNum()
            if (cur.isEmpty()) {
                cur = Regex("\"priceCurrency\"\\s*:\\s*\"([A-Z]{3})\"").find(ld)?.groupValues?.get(1).orEmpty()
            }
        }
        if (price == null) {
            price = d.selectFirst("[itemprop=price]")?.let { it.attr("content").ifEmpty { it.text() } }?.toNum()
        }
        if (title.isBlank()) null
        else Meta(
            title.take(120),
            m("og:description", "twitter:description", "description").take(200),
            image, price, cur.ifEmpty { currencyOf("", host) }
        )
    } catch (e: Exception) {
        null
    }
}
