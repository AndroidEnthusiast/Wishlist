package com.wishlist.app

/**
 * Online sharing uses a free Supabase project.
 * Paste your Project URL and your publishable (or anon) key between the quotes.
 * These two values are meant to be public, so it is fine to keep them in the app.
 */
object Config {
    const val SUPABASE_URL = "https://aspnmvmsvwbezdltykgx.supabase.co"
    const val SUPABASE_KEY = "sb_publishable_2RpbWlDJBB3yV2TO-h68xA_i-gXfd_t"

    val enabled: Boolean
        get() = SUPABASE_URL.isNotBlank() && SUPABASE_KEY.isNotBlank()
}
