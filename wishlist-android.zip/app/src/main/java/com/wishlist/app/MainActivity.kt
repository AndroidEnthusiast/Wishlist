package com.wishlist.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private var sharedUrl by mutableStateOf<String?>(null)
    private var sharedCode by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.load(this)
        handle(intent)
        addOnNewIntentListener { handle(it) }
        Alerts.ensureChannel(this)
        Alerts.schedule(this, Repo.intervalHours, false)
        Sync.push()
        setContent {
            WishTheme { App(sharedUrl, sharedCode) { sharedUrl = null; sharedCode = null } }
        }
    }

    private fun handle(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            val code = Sync.embeddedCode(t)
            if (code != null) sharedCode = code
            else cleanUrl(t)?.let { sharedUrl = it }
        }
    }

}

private val Green = Color(0xFF0B7A3E)

private fun host(url: String): String = try {
    java.net.URI(url).host.removePrefix("www.")
} catch (e: Exception) {
    url
}

@Composable
private fun DrawerItem(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, null) },
        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(sharedUrl: String?, sharedCode: String?, onSharedUsed: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    var adding by remember { mutableStateOf(false) }
    var prefill by remember { mutableStateOf("") }
    var catDlg by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var friendCode by remember { mutableStateOf<String?>(null) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    fun openFriend(code: String) {
        if (code == Repo.shareCode) {
            scope.launch { snack.showSnackbar("That’s your own list. Friends reserve from it, and you can’t peek.") }
            return
        }
        if (Repo.friends.any { it.code == code }) {
            friendCode = code; settings = false
            return
        }
        scope.launch {
            try {
                val r = Cloud.fetchList(code)
                if (r == null) {
                    snack.showSnackbar("No list found for that code.")
                } else {
                    Repo.addFriend(ctx, Friend(code, r.name))
                    friendCode = code; settings = false
                }
            } catch (e: Exception) {
                snack.showSnackbar("Couldn’t reach the server. Check your connection.")
            }
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(sharedUrl) {
        if (sharedUrl != null) {
            prefill = sharedUrl; adding = true; settings = false; friendCode = null
            onSharedUsed()
        }
    }
    LaunchedEffect(sharedCode) {
        if (sharedCode != null) {
            openFriend(sharedCode)
            onSharedUsed()
        }
    }

    BackHandler(enabled = drawer.isOpen) { scope.launch { drawer.close() } }
    BackHandler(enabled = !drawer.isOpen && (settings || friendCode != null)) {
        settings = false; friendCode = null
    }

    val openMenu: () -> Unit = { scope.launch { drawer.open() } }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        Repo.listName, style = MaterialTheme.typography.titleLarge,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 28.dp, vertical = 24.dp)
                    )
                    DrawerItem("My wishlist", Icons.Default.Favorite, !settings && friendCode == null) {
                        settings = false; friendCode = null
                        scope.launch { drawer.close() }
                    }
                    if (Repo.friends.isNotEmpty()) {
                        Text(
                            "Friends’ lists", style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 28.dp, top = 16.dp, bottom = 8.dp)
                        )
                        Repo.friends.forEach { f ->
                            DrawerItem(f.name, Icons.Default.Person, !settings && friendCode == f.code) {
                                friendCode = f.code; settings = false
                                scope.launch { drawer.close() }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    DrawerItem("Settings", Icons.Default.Settings, settings) {
                        settings = true; friendCode = null
                        scope.launch { drawer.close() }
                    }
                }
            }
        }
    ) {
        val fr = Repo.friends.firstOrNull { it.code == friendCode }
        when {
            settings -> SettingsScreen(snack, openMenu)
            fr != null -> FriendScreen(fr, snack, openMenu) { friendCode = null }
            else -> HomeScreen(
                snack, openMenu,
                onAdd = { prefill = ""; adding = true },
                onNewCat = { catDlg = true }
            )
        }
    }

    if (adding) key(prefill) { WishDialog(null, prefill) { adding = false } }
    if (catDlg) CategoryDialog { catDlg = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(snack: SnackbarHostState, onMenu: () -> Unit, onAdd: () -> Unit, onNewCat: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var cat by remember { mutableStateOf("All") }
    var catMenu by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Wish?>(null) }
    var detailId by remember { mutableStateOf<Long?>(null) }
    val sel = if (cat == "All" || cat in Repo.cats) cat else "All"
    val list = Repo.wishes.filter { sel == "All" || it.category == sel }
    val view = Repo.view

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(Repo.listName, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                navigationIcon = { IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "Menu") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background),
                actions = {
                    IconButton(onClick = {
                        WorkManager.getInstance(ctx).enqueue(OneTimeWorkRequestBuilder<PriceWorker>().build())
                        scope.launch { snack.showSnackbar("Checking prices…") }
                    }) { Icon(Icons.Default.Refresh, "Check prices now") }
                    IconButton(onClick = { startShare(ctx, scope, snack) }) {
                        Icon(Icons.Default.Share, "Share wishlist")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAdd,
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("Add") },
                containerColor = cs.primaryContainer,
                contentColor = cs.onPrimaryContainer
            )
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 2.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {
                    Row(
                        Modifier.clip(RoundedCornerShape(12.dp)).clickable { catMenu = true }
                            .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            sel, style = MaterialTheme.typography.titleMedium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 200.dp)
                        )
                        Icon(Icons.Default.ArrowDropDown, "Choose category")
                    }
                    DropdownMenu(expanded = catMenu, onDismissRequest = { catMenu = false }) {
                        (listOf("All") + Repo.cats).forEach { c ->
                            val n = if (c == "All") Repo.wishes.size else Repo.wishes.count { it.category == c }
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        "$c ($n)",
                                        fontWeight = if (c == sel) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = { cat = c; catMenu = false }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("New category…") },
                            leadingIcon = { Icon(Icons.Default.Add, null) },
                            onClick = { catMenu = false; onNewCat() }
                        )
                    }
                }
                Spacer(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    ViewButton("list", "Large cards", view == "list") { Repo.setView(ctx, "list") }
                    ViewButton("grid", "Two per row", view == "grid") { Repo.setView(ctx, "grid") }
                    ViewButton("gallery", "Images only", view == "gallery") { Repo.setView(ctx, "gallery") }
                }
            }
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                    Text(
                        "Nothing here yet. Tap Add, or share a product link to Wishlist from your browser.",
                        color = cs.onSurfaceVariant
                    )
                }
            } else {
                val gap = when (view) { "gallery" -> 8.dp; "grid" -> 12.dp; else -> 16.dp }
                LazyVerticalGrid(
                    columns = when (view) {
                        "gallery" -> GridCells.Adaptive(100.dp)
                        "grid" -> GridCells.Fixed(2)
                        else -> GridCells.Adaptive(300.dp)
                    },
                    contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(gap),
                    verticalArrangement = Arrangement.spacedBy(gap)
                ) {
                    gridItems(list, key = { it.id }) { w ->
                        when (view) {
                            "gallery" -> ImageTile(w) { detailId = w.id }
                            "grid" -> CompactCard(w) { editing = w }
                            else -> WishCard(w, badge = if (w.got) "Got it" else null, dim = w.got) {
                                IconButton(onClick = { editing = w }) {
                                    Icon(Icons.Default.Edit, "Edit", tint = cs.onSurfaceVariant)
                                }
                                IconButton(onClick = { Repo.replace(ctx, w.copy(got = !w.got)) }) {
                                    Icon(
                                        Icons.Default.Check, "Mark as got",
                                        tint = if (w.got) cs.primary else cs.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { Repo.remove(ctx, w.id) }) {
                                    Icon(Icons.Default.Delete, "Remove", tint = cs.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    editing?.let { w -> key(w.id) { WishDialog(w, "") { editing = null } } }
    detailId?.let { id -> Repo.wishes.firstOrNull { it.id == id } }?.let { w ->
        WishDetailDialog(w, onEdit = { editing = w }) { detailId = null }
    }
}

/** One of the three view buttons in the row above the wishes. */
@Composable
private fun ViewButton(kind: String, label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
            .background(if (selected) cs.primaryContainer else Color.Transparent)
            .semantics { contentDescription = label }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        ViewIcon(kind, if (selected) cs.onPrimaryContainer else cs.onSurfaceVariant)
    }
}

/** Tiny drawn icons: two wide bars, a 2x2 grid, a 3x3 grid. */
@Composable
private fun ViewIcon(kind: String, tint: Color) {
    Canvas(Modifier.size(22.dp)) {
        val u = size.width / 24f
        fun box(x: Float, y: Float, w: Float, h: Float) = drawRoundRect(
            color = tint, topLeft = Offset(x * u, y * u), size = Size(w * u, h * u),
            cornerRadius = CornerRadius(1.6f * u, 1.6f * u)
        )
        when (kind) {
            "list" -> { box(3f, 4f, 18f, 7f); box(3f, 13f, 18f, 7f) }
            "grid" -> { box(3f, 3f, 8f, 8f); box(13f, 3f, 8f, 8f); box(3f, 13f, 8f, 8f); box(13f, 13f, 8f, 8f) }
            else -> repeat(3) { r -> repeat(3) { c -> box(3f + c * 6.8f, 3f + r * 6.8f, 5.2f, 5.2f) } }
        }
    }
}

/** Two-per-row card: picture, title and price, with edit / got it / remove in a small menu. */
@Composable
fun CompactCard(w: Wish, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    val ui = LocalUriHandler.current
    val cs = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf(false) }
    val oldP = w.oldPrice
    val newP = w.price
    val drop = newP != null && oldP != null && oldP > newP

    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().alpha(if (w.got) 0.6f else 1f)
    ) {
        Box(
            Modifier.fillMaxWidth().height(130.dp)
                .background(if (w.image.isEmpty()) cs.primaryContainer else Color.White)
                .clickable { try { ui.openUri(w.url) } catch (e: Exception) { } },
            contentAlignment = Alignment.Center
        ) {
            if (w.image.isNotEmpty()) {
                AsyncImage(
                    model = w.image, contentDescription = w.title,
                    contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(6.dp)
                )
            } else Text("🎁", fontSize = 36.sp)
            if (drop && newP != null && oldP != null) {
                Surface(
                    color = Green, shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
                ) {
                    Text(
                        "↓ ${Math.round((1 - newP / oldP) * 100)}%", color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            if (w.got) {
                Surface(
                    color = cs.background, shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
                ) {
                    Text(
                        "Got it", color = cs.onBackground, style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
        Row(Modifier.padding(start = 12.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(
                    w.title, style = MaterialTheme.typography.titleSmall,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, color = cs.onSurface
                )
                Text(
                    if (newP != null) money(newP, w.currency) else "No price",
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, color = if (drop) Green else cs.onSurface,
                    modifier = Modifier.padding(top = 2.dp, bottom = 6.dp)
                )
            }
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Default.MoreVert, "More", tint = cs.onSurfaceVariant)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; onEdit() })
                    DropdownMenuItem(
                        text = { Text(if (w.got) "Mark as not got" else "Mark as got") },
                        onClick = { menu = false; Repo.replace(ctx, w.copy(got = !w.got)) }
                    )
                    DropdownMenuItem(text = { Text("Remove") }, onClick = { menu = false; Repo.remove(ctx, w.id) })
                }
            }
        }
    }
}

/** Images-only tile: the picture fills the square and the price sits in a tag on top of it. */
@Composable
fun ImageTile(w: Wish, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val oldP = w.oldPrice
    val newP = w.price
    val drop = newP != null && oldP != null && oldP > newP

    Box(
        Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(14.dp))
            .background(if (w.image.isEmpty()) cs.primaryContainer else Color.White)
            .alpha(if (w.got) 0.55f else 1f)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (w.image.isNotEmpty()) {
            AsyncImage(
                model = w.image, contentDescription = w.title,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
            )
        } else Text("🎁", fontSize = 32.sp)
        Surface(
            color = if (drop) Green else Color.Black.copy(alpha = 0.72f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
        ) {
            Text(
                if (newP != null) money(newP, w.currency) else "No price",
                color = Color.White, style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold, maxLines = 1,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
        if (w.got) {
            Surface(
                color = cs.background, shape = RoundedCornerShape(6.dp),
                modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
            ) {
                Text(
                    "Got it", color = cs.onBackground, style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}

/** Opens when you tap an images-only tile: the details, plus everything the cards have as buttons. */
@Composable
fun WishDetailDialog(w: Wish, onEdit: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val ui = LocalUriHandler.current
    val cs = MaterialTheme.colorScheme
    val label = if (w.category.isBlank()) "" else " · " + w.category
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(w.title, maxLines = 3, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (w.image.isNotEmpty()) {
                    AsyncImage(
                        model = w.image, contentDescription = null, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().height(200.dp)
                            .clip(RoundedCornerShape(12.dp)).background(Color.White)
                    )
                }
                Row(verticalAlignment = Alignment.Bottom) {
                    val p = w.price
                    val o = w.oldPrice
                    Text(
                        if (p != null) money(p, w.currency) else "No price",
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold
                    )
                    if (p != null && o != null && o > p) {
                        Text(
                            money(o, w.currency), style = MaterialTheme.typography.bodyMedium,
                            textDecoration = TextDecoration.LineThrough, color = cs.onSurfaceVariant,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }
                Text(host(w.url) + label, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                if (w.desc.isNotBlank()) {
                    Text(w.desc, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { onClose(); onEdit() }) { Text("Edit") }
                    TextButton(onClick = { Repo.replace(ctx, w.copy(got = !w.got)); onClose() }) {
                        Text(if (w.got) "Not got" else "Got it")
                    }
                    TextButton(onClick = { Repo.remove(ctx, w.id); onClose() }) { Text("Remove") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { try { ui.openUri(w.url) } catch (e: Exception) { } }) { Text("Open in store") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}

/** One wish. [actions] are the buttons at the bottom right, which differ for the owner and for friends. */
@Composable
fun WishCard(w: Wish, badge: String? = null, dim: Boolean = false, actions: @Composable RowScope.() -> Unit) {
    val ui = LocalUriHandler.current
    val cs = MaterialTheme.colorScheme
    val oldP = w.oldPrice
    val newP = w.price
    val drop = newP != null && oldP != null && oldP > newP
    val label = if (w.category.isBlank() || w.category == "All") "" else " · " + w.category

    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().alpha(if (dim) 0.6f else 1f)
    ) {
        Box(
            Modifier.fillMaxWidth().height(160.dp)
                .background(if (w.image.isEmpty()) cs.primaryContainer else Color.White)
                .clickable { try { ui.openUri(w.url) } catch (e: Exception) { } },
            contentAlignment = Alignment.Center
        ) {
            if (w.image.isNotEmpty()) {
                AsyncImage(
                    model = w.image, contentDescription = w.title,
                    contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(8.dp)
                )
            } else Text("🎁", fontSize = 48.sp)
            if (drop && newP != null && oldP != null) {
                Surface(
                    color = Green, shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
                ) {
                    Text(
                        "↓ ${Math.round((1 - newP / oldP) * 100)}% off", color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
            if (badge != null) {
                Surface(
                    color = cs.background, shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                ) {
                    Text(
                        badge, color = cs.onBackground, style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }
        Column(Modifier.padding(16.dp)) {
            Text(
                host(w.url) + label,
                style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant
            )
            Text(
                w.title, style = MaterialTheme.typography.titleMedium,
                maxLines = 2, overflow = TextOverflow.Ellipsis, color = cs.onSurface
            )
            if (w.desc.isNotBlank()) {
                Text(
                    w.desc, style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant
                )
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom) {
                    Text(
                        if (newP != null) money(newP, w.currency) else "No price",
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold,
                        color = if (drop) Green else cs.onSurface
                    )
                    if (drop && oldP != null) {
                        Text(
                            money(oldP, w.currency), style = MaterialTheme.typography.bodyMedium,
                            textDecoration = TextDecoration.LineThrough, color = cs.onSurfaceVariant,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }
                actions()
            }
        }
    }
}

/** Adds a new wish, or edits [edit] when it is not null. */
@Composable
fun WishDialog(edit: Wish?, initialUrl: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var url by remember { mutableStateOf(edit?.url ?: initialUrl) }
    var title by remember { mutableStateOf(edit?.title ?: "") }
    var price by remember { mutableStateOf(edit?.price?.let { "%.2f".format(Locale.US, it) } ?: "") }
    var desc by remember { mutableStateOf(edit?.desc ?: "") }
    var image by remember { mutableStateOf(edit?.image ?: "") }
    var cur by remember { mutableStateOf(edit?.currency ?: "USD") }
    var cat by remember { mutableStateOf(if (edit != null) edit.category else (Repo.cats.firstOrNull() ?: "")) }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }

    fun go() {
        val u = cleanUrl(url)
        if (u == null) { err = "Enter a full product link"; return }
        url = u; busy = true; err = ""
        scope.launch {
            val m = fetchMeta(u, ctx)
            busy = false
            if (m == null) {
                err = "Couldn’t read that page. Fill in the details yourself."
            } else if (m.blocked) {
                err = "The store blocked the automatic read. Enter the title and price yourself."
            } else {
                title = m.title; desc = m.desc; image = m.image; cur = m.currency
                if (m.price != null || edit == null) price = m.price?.let { "%.2f".format(Locale.US, it) }.orEmpty()
                if (m.price == null) err = "No price found on that page. Add it to track price drops."
            }
        }
    }
    LaunchedEffect(Unit) { if (edit == null && initialUrl.isNotEmpty()) go() }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (edit == null) "Add a wish" else "Edit wish") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    url, { url = it }, label = { Text("Product link") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { clip.getText()?.text?.let { url = it } }) { Text("Paste") }
                    Button(onClick = { go() }, enabled = !busy) { Text(if (busy) "Reading…" else "Fetch details") }
                }
                if (err.isNotEmpty()) {
                    Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                if (image.isNotEmpty()) {
                    AsyncImage(
                        model = image, contentDescription = null, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().height(120.dp)
                            .clip(RoundedCornerShape(12.dp)).background(Color.White)
                    )
                }
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    price, { price = it }, label = { Text("Price ($cur)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    desc, { desc = it }, label = { Text("Description") },
                    maxLines = 3, modifier = Modifier.fillMaxWidth()
                )
                if (Repo.cats.isNotEmpty()) {
                    Text("Category", style = MaterialTheme.typography.labelMedium)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Repo.cats.forEach { c ->
                            FilterChip(selected = c == cat, onClick = { cat = if (cat == c) "" else c }, label = { Text(c) })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = url.isNotBlank() && title.isNotBlank(),
                onClick = {
                    val p = price.replace(',', '.').toDoubleOrNull()
                    val u = cleanUrl(url) ?: url.trim()
                    if (edit == null) {
                        Repo.add(ctx, Wish(System.currentTimeMillis(), u, title.trim(), desc, image, p, null, cur, cat))
                    } else {
                        Repo.replace(
                            ctx,
                            edit.copy(
                                url = u, title = title.trim(), desc = desc, image = image, price = p,
                                oldPrice = if (p == edit.price) edit.oldPrice else null,
                                currency = cur, category = cat
                            )
                        )
                    }
                    onClose()
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
fun CategoryDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("New category") },
        text = { OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { Repo.addCat(ctx, name); onClose() }) { Text("Add") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
