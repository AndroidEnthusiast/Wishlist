package com.wishlist.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private var sharedUrl by mutableStateOf<String?>(null)
    private var sharedCode by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.load(this)
        handle(intent)
        addOnNewIntentListener { handle(it) }
        schedulePriceChecks()
        Sync.push()
        setContent {
            WishTheme { App(sharedUrl, sharedCode) { sharedUrl = null; sharedCode = null } }
        }
    }

    private fun handle(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            val code = Sync.embeddedCode(t)
            if (code != null) sharedCode = code
            else cleanUrl(t)?.let { sharedUrl = it }
        }
    }

    private fun schedulePriceChecks() {
        val req = PeriodicWorkRequestBuilder<PriceWorker>(6, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this)
            .enqueueUniquePeriodicWork("prices", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

private val Green = Color(0xFF0B7A3E)

private fun host(url: String): String = try {
    java.net.URI(url).host.removePrefix("www.")
} catch (e: Exception) {
    url
}

@Composable
private fun DrawerItem(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, null) },
        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(sharedUrl: String?, sharedCode: String?, onSharedUsed: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    var adding by remember { mutableStateOf(false) }
    var prefill by remember { mutableStateOf("") }
    var catDlg by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var friendCode by remember { mutableStateOf<String?>(null) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    fun openFriend(code: String) {
        if (code == Repo.shareCode) {
            scope.launch { snack.showSnackbar("That’s your own list. Friends reserve from it, and you can’t peek.") }
            return
        }
        if (Repo.friends.any { it.code == code }) {
            friendCode = code; settings = false
            return
        }
        scope.launch {
            try {
                val r = Cloud.fetchList(code)
                if (r == null) {
                    snack.showSnackbar("No list found for that code.")
                } else {
                    Repo.addFriend(ctx, Friend(code, r.name))
                    friendCode = code; settings = false
                }
            } catch (e: Exception) {
                snack.showSnackbar("Couldn’t reach the server. Check your connection.")
            }
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(sharedUrl) {
        if (sharedUrl != null) {
            prefill = sharedUrl; adding = true; settings = false; friendCode = null
            onSharedUsed()
        }
    }
    LaunchedEffect(sharedCode) {
        if (sharedCode != null) {
            openFriend(sharedCode)
            onSharedUsed()
        }
    }

    BackHandler(enabled = drawer.isOpen) { scope.launch { drawer.close() } }
    BackHandler(enabled = !drawer.isOpen && (settings || friendCode != null)) {
        settings = false; friendCode = null
    }

    val openMenu: () -> Unit = { scope.launch { drawer.open() } }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        Repo.listName, style = MaterialTheme.typography.titleLarge,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 28.dp, vertical = 24.dp)
                    )
                    DrawerItem("My wishlist", Icons.Default.Favorite, !settings && friendCode == null) {
                        settings = false; friendCode = null
                        scope.launch { drawer.close() }
                    }
                    if (Repo.friends.isNotEmpty()) {
                        Text(
                            "Friends’ lists", style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 28.dp, top = 16.dp, bottom = 8.dp)
                        )
                        Repo.friends.forEach { f ->
                            DrawerItem(f.name, Icons.Default.Person, !settings && friendCode == f.code) {
                                friendCode = f.code; settings = false
                                scope.launch { drawer.close() }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    DrawerItem("Settings", Icons.Default.Settings, settings) {
                        settings = true; friendCode = null
                        scope.launch { drawer.close() }
                    }
                }
            }
        }
    ) {
        val fr = Repo.friends.firstOrNull { it.code == friendCode }
        when {
            settings -> SettingsScreen(snack, openMenu)
            fr != null -> FriendScreen(fr, snack, openMenu) { friendCode = null }
            else -> HomeScreen(
                snack, openMenu,
                onAdd = { prefill = ""; adding = true },
                onNewCat = { catDlg = true }
            )
        }
    }

    if (adding) key(prefill) { WishDialog(null, prefill) { adding = false } }
    if (catDlg) CategoryDialog { catDlg = false }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(snack: SnackbarHostState, onMenu: () -> Unit, onAdd: () -> Unit, onNewCat: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var cat by remember { mutableStateOf("All") }
    var editing by remember { mutableStateOf<Wish?>(null) }
    val sel = if (cat == "All" || cat in Repo.cats) cat else "All"
    val list = Repo.wishes.filter { sel == "All" || it.category == sel }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(Repo.listName, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                navigationIcon = { IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "Menu") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                actions = {
                    IconButton(onClick = {
                        WorkManager.getInstance(ctx).enqueue(OneTimeWorkRequestBuilder<PriceWorker>().build())
                        scope.launch { snack.showSnackbar("Checking prices…") }
                    }) { Icon(Icons.Default.Refresh, "Check prices now") }
                    IconButton(onClick = { startShare(ctx, scope, snack) }) {
                        Icon(Icons.Default.Share, "Share wishlist")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAdd,
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("Add") },
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
            )
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf("All") + Repo.cats) { c ->
                    FilterChip(selected = c == sel, onClick = { cat = c }, label = { Text(c) })
                }
                item {
                    AssistChip(
                        onClick = onNewCat,
                        label = { Text("New") },
                        leadingIcon = { Icon(Icons.Default.Add, null, Modifier.size(18.dp)) }
                    )
                }
            }
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                    Text(
                        "Nothing here yet. Tap Add, or share a product link to Wishlist from your browser.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(300.dp),
                    contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    gridItems(list, key = { it.id }) { w ->
                        WishCard(w, badge = if (w.got) "Got it" else null, dim = w.got) {
                            IconButton(onClick = { editing = w }) {
                                Icon(Icons.Default.Edit, "Edit", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { Repo.replace(ctx, w.copy(got = !w.got)) }) {
                                Icon(
                                    Icons.Default.Check, "Mark as got",
                                    tint = if (w.got) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { Repo.remove(ctx, w.id) }) {
                                Icon(Icons.Default.Delete, "Remove", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }

    editing?.let { w -> key(w.id) { WishDialog(w, "") { editing = null } } }
}

/** One wish. [actions] are the buttons at the bottom right, which differ for the owner and for friends. */
@Composable
fun WishCard(w: Wish, badge: String? = null, dim: Boolean = false, actions: @Composable RowScope.() -> Unit) {
    val ui = LocalUriHandler.current
    val cs = MaterialTheme.colorScheme
    val oldP = w.oldPrice
    val newP = w.price
    val drop = newP != null && oldP != null && oldP > newP
    val label = if (w.category.isBlank() || w.category == "All") "" else " · " + w.category

    Card(
        colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().alpha(if (dim) 0.6f else 1f)
    ) {
        Box(
            Modifier.fillMaxWidth().height(160.dp)
                .background(if (w.image.isEmpty()) cs.primaryContainer else Color.White)
                .clickable { try { ui.openUri(w.url) } catch (e: Exception) { } },
            contentAlignment = Alignment.Center
        ) {
            if (w.image.isNotEmpty()) {
                AsyncImage(
                    model = w.image, contentDescription = w.title,
                    contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(8.dp)
                )
            } else Text("🎁", fontSize = 48.sp)
            if (drop && newP != null && oldP != null) {
                Surface(
                    color = Green, shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
                ) {
                    Text(
                        "↓ ${Math.round((1 - newP / oldP) * 100)}% off", color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
            if (badge != null) {
                Surface(
                    color = cs.background, shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                ) {
                    Text(
                        badge, color = cs.onBackground, style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }
        Column(Modifier.padding(16.dp)) {
            Text(
                host(w.url) + label,
                style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant
            )
            Text(
                w.title, style = MaterialTheme.typography.titleMedium,
                maxLines = 2, overflow = TextOverflow.Ellipsis, color = cs.onSurface
            )
            if (w.desc.isNotBlank()) {
                Text(
                    w.desc, style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant
                )
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom) {
                    Text(
                        if (newP != null) money(newP, w.currency) else "No price",
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold,
                        color = if (drop) Green else cs.onSurface
                    )
                    if (drop && oldP != null) {
                        Text(
                            money(oldP, w.currency), style = MaterialTheme.typography.bodyMedium,
                            textDecoration = TextDecoration.LineThrough, color = cs.onSurfaceVariant,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }
                actions()
            }
        }
    }
}

/** Adds a new wish, or edits [edit] when it is not null. */
@Composable
fun WishDialog(edit: Wish?, initialUrl: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var url by remember { mutableStateOf(edit?.url ?: initialUrl) }
    var title by remember { mutableStateOf(edit?.title ?: "") }
    var price by remember { mutableStateOf(edit?.price?.let { "%.2f".format(Locale.US, it) } ?: "") }
    var desc by remember { mutableStateOf(edit?.desc ?: "") }
    var image by remember { mutableStateOf(edit?.image ?: "") }
    var cur by remember { mutableStateOf(edit?.currency ?: "USD") }
    var cat by remember { mutableStateOf(if (edit != null) edit.category else (Repo.cats.firstOrNull() ?: "")) }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }

    fun go() {
        val u = cleanUrl(url)
        if (u == null) { err = "Enter a full product link"; return }
        url = u; busy = true; err = ""
        scope.launch {
            val m = fetchMeta(u)
            busy = false
            if (m == null) {
                err = "Couldn’t read that page. Fill in the details yourself."
            } else if (m.blocked) {
                err = "The store blocked the automatic read. Enter the title and price yourself."
            } else {
                title = m.title; desc = m.desc; image = m.image; cur = m.currency
                if (m.price != null || edit == null) price = m.price?.let { "%.2f".format(Locale.US, it) }.orEmpty()
                if (m.price == null) err = "No price found on that page. Add it to track price drops."
            }
        }
    }
    LaunchedEffect(Unit) { if (edit == null && initialUrl.isNotEmpty()) go() }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (edit == null) "Add a wish" else "Edit wish") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    url, { url = it }, label = { Text("Product link") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { clip.getText()?.text?.let { url = it } }) { Text("Paste") }
                    Button(onClick = { go() }, enabled = !busy) { Text(if (busy) "Reading…" else "Fetch details") }
                }
                if (err.isNotEmpty()) {
                    Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                if (image.isNotEmpty()) {
                    AsyncImage(
                        model = image, contentDescription = null, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().height(120.dp)
                            .clip(RoundedCornerShape(12.dp)).background(Color.White)
                    )
                }
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    price, { price = it }, label = { Text("Price ($cur)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    desc, { desc = it }, label = { Text("Description") },
                    maxLines = 3, modifier = Modifier.fillMaxWidth()
                )
                if (Repo.cats.isNotEmpty()) {
                    Text("Category", style = MaterialTheme.typography.labelMedium)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Repo.cats.forEach { c ->
                            FilterChip(selected = c == cat, onClick = { cat = if (cat == c) "" else c }, label = { Text(c) })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = url.isNotBlank() && title.isNotBlank(),
                onClick = {
                    val p = price.replace(',', '.').toDoubleOrNull()
                    val u = cleanUrl(url) ?: url.trim()
                    if (edit == null) {
                        Repo.add(ctx, Wish(System.currentTimeMillis(), u, title.trim(), desc, image, p, null, cur, cat))
                    } else {
                        Repo.replace(
                            ctx,
                            edit.copy(
                                url = u, title = title.trim(), desc = desc, image = image, price = p,
                                oldPrice = if (p == edit.price) edit.oldPrice else null,
                                currency = cur, category = cat
                            )
                        )
                    }
                    onClose()
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
fun CategoryDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("New category") },
        text = { OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { Repo.addCat(ctx, name); onClose() }) { Text("Add") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
