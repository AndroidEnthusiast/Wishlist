package com.wishlist.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlin.math.abs

class PriceWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        Repo.load(c)
        for (w in Repo.wishes) {
            if (w.got) continue
            val np = fetchMeta(w.url)?.price ?: continue
            val cur = w.price
            when {
                cur == null -> Repo.replace(c, w.copy(price = np))
                np < cur - 0.005 -> {
                    Repo.replace(c, w.copy(price = np, oldPrice = cur))
                    notifyDrop(c, w, cur, np)
                }
                abs(np - cur) > 0.005 -> Repo.replace(c, w.copy(price = np, oldPrice = null))
            }
        }
        return Result.success()
    }

    private fun notifyDrop(c: Context, w: Wish, old: Double, now: Double) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("drops", "Price drops", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val pi = PendingIntent.getActivity(
            c, w.id.toInt(), Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, "drops")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Price drop: ${w.title}")
            .setContentText("Was ${money(old, w.currency)}, now ${money(now, w.currency)}")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(w.id.toInt(), n)
    }
}
