package com.wishlist.app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlin.math.abs

class PriceWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        Repo.load(c)
        for (w in Repo.wishes.toList()) {
            if (w.got || w.url.isBlank()) continue
            // Items that already have a price may use the slower hidden-browser read; priceless ones are skipped cheaply.
            val np = fetchMeta(w.url, c, w.price != null)?.price ?: continue
            // Re-read the wish: it may have been edited while the page was loading.
            val cw = Repo.wishes.firstOrNull { it.id == w.id } ?: continue
            val cur = cw.price
            when {
                cur == null -> Repo.replace(c, cw.copy(price = np))
                np < cur - 0.005 -> {
                    Repo.replace(c, cw.copy(price = np, oldPrice = cur))
                    Alerts.notifyDrop(c, cw.id.toInt(), cw.title, cur, np, cw.currency)
                }
                abs(np - cur) > 0.005 -> Repo.replace(c, cw.copy(price = np, oldPrice = null))
            }
        }
        Repo.setLastCheck(c, System.currentTimeMillis())
        // Make sure friends see the new prices even if the app is closed right after.
        try {
            Sync.pushNow()
        } catch (e: Exception) {
        }
        return Result.success()
    }
}
