package com.wishlist.app

import android.text.format.DateUtils
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
private fun SectionTitle(t: String) {
    Text(
        t, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 20.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(snack: SnackbarHostState, onMenu: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var name by remember { mutableStateOf(Repo.listName) }
    var newCat by remember { mutableStateOf("") }
    var delCat by remember { mutableStateOf<String?>(null) }
    var renCat by remember { mutableStateOf<String?>(null) }
    var stopDlg by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Medium) },
                navigationIcon = { MenuSlot() },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background)
            )
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SectionTitle("Wishlist name")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(name, { name = it }, singleLine = true, modifier = Modifier.weight(1f))
                Button(onClick = {
                    Repo.setListName(ctx, name)
                    name = Repo.listName
                    scope.launch { snack.showSnackbar("Name saved") }
                }) { Text("Save") }
            }

            SectionTitle("Categories")
            if (Repo.cats.isEmpty()) {
                Text("No categories yet.", color = cs.onSurfaceVariant)
            }
            Repo.cats.forEach { c ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(c, Modifier.weight(1f))
                    IconButton(onClick = { renCat = c }) {
                        Icon(Icons.Default.Edit, "Edit $c", tint = cs.onSurfaceVariant)
                    }
                    IconButton(onClick = { delCat = c }) {
                        Icon(Icons.Default.Delete, "Remove $c", tint = cs.onSurfaceVariant)
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    newCat, { newCat = it }, label = { Text("New category") },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
                Button(onClick = { Repo.addCat(ctx, newCat); newCat = "" }) { Text("Add") }
            }

            SectionTitle("Theme")
            listOf(
                "system" to "System default", "light" to "Light",
                "dark" to "Dark", "amoled" to "AMOLED black"
            ).forEach { (k, n) ->
                Row(
                    Modifier.fillMaxWidth().clickable { Repo.setTheme(ctx, k) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = Repo.theme == k, onClick = { Repo.setTheme(ctx, k) })
                    Text(n)
                }
            }

            SectionTitle("Price alerts")
            Text(
                "Wishlist checks your wishes in the background and sends a notification when a price drops. " +
                    "Android decides the exact timing, so checks can be later than the interval.",
                color = cs.onSurfaceVariant
            )
            Text("Check every", style = MaterialTheme.typography.labelMedium)
            listOf(1, 3, 6, 12, 24).forEach { h ->
                val pick = {
                    Repo.setInterval(ctx, h)
                    Alerts.schedule(ctx, h, true)
                }
                Row(Modifier.fillMaxWidth().clickable { pick() }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = Repo.intervalHours == h, onClick = { pick() })
                    Text(if (h == 1) "Every hour" else "Every $h hours")
                }
            }
            Text(
                if (Repo.lastCheck == 0L) "No background check has finished yet."
                else "Last check: " + DateUtils.getRelativeTimeSpanString(Repo.lastCheck),
                color = cs.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    Alerts.checkNow(ctx)
                    scope.launch { snack.showSnackbar("Checking prices…") }
                }) { Text("Check now") }
                OutlinedButton(onClick = {
                    val ok = Alerts.sendTest(ctx)
                    scope.launch {
                        snack.showSnackbar(
                            if (ok) "Test notification sent"
                            else "Notifications are off for Wishlist. Open Notification settings."
                        )
                    }
                }) { Text("Test notification") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { Alerts.openNotificationSettings(ctx) }) { Text("Notification settings") }
                OutlinedButton(onClick = { Alerts.openAppSettings(ctx) }) { Text("Battery settings") }
            }
            Text(
                "For reliable alerts: in Battery settings set Wishlist to Unrestricted (the wording varies by phone, " +
                    "for example “Don’t optimize” or “Allow background activity”), and don’t use Force stop on the app.",
                color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall
            )

            SectionTitle("Sharing")
            val code = Repo.shareCode
            if (!Config.enabled) {
                Text("Online sharing isn’t set up in this build yet.", color = cs.onSurfaceVariant)
            } else if (code == null) {
                Text(
                    "Not shared yet. Share your list so friends can reserve gifts. You won’t see what they reserve.",
                    color = cs.onSurfaceVariant
                )
                Button(onClick = { startShare(ctx, scope, snack) }) { Text("Share my wishlist") }
            } else {
                Text("Friends open this link and tap Reserve:", color = cs.onSurfaceVariant)
                Text(shareLink(code), color = cs.onSurface)
                if (Sync.photoStatus.isNotEmpty()) {
                    Text(Sync.photoStatus, color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
                Text(
                    "Don’t open your own link in a browser, or you’ll see what’s reserved.",
                    color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { startShare(ctx, scope, snack) }) { Text("Share again") }
                    OutlinedButton(onClick = {
                        clip.setText(AnnotatedString(shareLink(code)))
                        scope.launch { snack.showSnackbar("Link copied") }
                    }) { Text("Copy link") }
                }
                TextButton(onClick = { stopDlg = true }) { Text("Stop sharing") }
            }
            TextButton(onClick = { shareList(ctx, Repo.wishes) }) { Text("Export as plain text") }

            SectionTitle("Share the app")
            Text(
                "Send the Wishlist APK to a friend so they can open your list. Gmail blocks APK files, so use a chat app or Drive.",
                color = cs.onSurfaceVariant
            )
            Button(onClick = {
                scope.launch {
                    try {
                        shareApk(ctx)
                    } catch (e: Exception) {
                        snack.showSnackbar("Couldn’t share the app")
                    }
                }
            }) { Text("Share app (APK)") }
        }
    }

    delCat?.let { dc -> DeleteCategoryDialog(dc, onDeleted = {}, onClose = { delCat = null }) }
    renCat?.let { rc -> RenameCategoryDialog(rc, onRenamed = {}, onClose = { renCat = null }) }
    if (stopDlg) {
        AlertDialog(
            onDismissRequest = { stopDlg = false },
            title = { Text("Stop sharing?") },
            text = { Text("The link stops working and all reservations are deleted. Sharing again later creates a new link.") },
            confirmButton = {
                TextButton(onClick = {
                    stopDlg = false
                    scope.launch {
                        try {
                            Sync.unpublish(ctx)
                        } catch (e: Exception) {
                            snack.showSnackbar("Couldn’t stop sharing. Check your connection.")
                        }
                    }
                }) { Text("Stop sharing") }
            },
            dismissButton = { TextButton(onClick = { stopDlg = false }) { Text("Cancel") } }
        )
    }
}
