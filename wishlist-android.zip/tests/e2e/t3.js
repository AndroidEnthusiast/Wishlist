const { boot, done, check, summary, KEY, CODE, sleep } = require("./lib.js");
const settle = (t) => t.page.waitForFunction(() => window.__wl.pending() === 0);
(async () => {
  // ---- star: effect and saving ----
  let t = await boot();
  await t.page.waitForSelector(".card");
  const shirt = t.page.locator(".card", { hasText: "Blue shirt" });
  await shirt.locator("[data-star]").click();
  await t.page.waitForSelector(".card[data-id='1002'] .sparks", { state: "attached" });
  check("7 sparkles", (await t.page.locator(".card[data-id='1002'] .sparks i").count()) === 7);
  check("pulse class", (await t.page.locator(".card[data-id='1002'] [data-star].pulse").count()) === 1);
  check("the star is now the gold label", /Most wanted/.test(await t.page.locator(".card[data-id='1002'] .badge.star").innerText()));
  await t.page.screenshot({ path: "shot_sparks.png", clip: { x: 0, y: 330, width: 390, height: 300 } });
  await settle(t);
  let p = t.fake.calls("wl_sh_put_item").pop();
  check("only star sent", JSON.stringify(p.body.p_fields) === JSON.stringify(["star"]), p.body.p_fields);
  check("star true online", t.fake.lists[CODE].items[1002].star === true);
  await sleep(1000);
  check("sparkles removed afterwards", (await t.page.locator(".sparks", { state: "attached" }).count()) === 0);
  // remove the star by tapping the label: no sparkles, star key removed online
  await t.page.locator(".card[data-id='1002'] .badge.star").click();
  await settle(t);
  check("star removed online (key gone)", !("star" in t.fake.lists[CODE].items[1002]));
  check("no sparkles when removing", (await t.page.locator(".sparks", { state: "attached" }).count()) === 0);
  // grid view: round star with effect
  await t.page.getByLabel("Two per row").click();
  await t.page.locator(".card.compact[data-id='1002'] .starbtn").click();
  await t.page.waitForSelector(".card.compact[data-id='1002'] .sparks", { state: "attached" });
  check("grid: sparkles", (await t.page.locator(".card.compact[data-id='1002'] .sparks i").count()) === 7);
  await settle(t);
  check("grid: star saved", t.fake.lists[CODE].items[1002].star === true);
  await t.page.locator(".card.compact[data-id='1002'] .starbtn").click();
  await settle(t);
  check("grid: tap again removes it", !("star" in t.fake.lists[CODE].items[1002]));
  check("grid: the button is outline again", (await t.page.locator(".card.compact[data-id='1002'] .starbtn.on").count()) === 0);
  // detail modal star
  await t.page.getByLabel("Images only").click();
  await t.page.locator(".tile[data-id='1002']").click();
  await t.page.locator("#modal [data-star]").click();
  await t.page.waitForSelector("#modal .sparks", { state: "attached" });
  await settle(t);
  check("modal: starred", t.fake.lists[CODE].items[1002].star === true);
  await t.page.keyboard.press("Escape");
  check("tile shows the star", (await t.page.locator(".tile[data-id='1002'] .badge.star").count()) === 1);
  await t.ctx.close();

  // reduced motion: no sparkles
  t = await boot({ reduced: true });
  await t.page.waitForSelector(".card");
  await t.page.locator(".card", { hasText: "Blue shirt" }).locator("[data-star]").click();
  await settle(t);
  await sleep(200);
  check("reduced motion: no sparkles", (await t.page.locator(".sparks", { state: "attached" }).count()) === 0);
  check("reduced motion: still saved", t.fake.lists[CODE].items[1002].star === true);
  await t.ctx.close();

  // ---- got it ----
  t = await boot();
  await t.page.waitForSelector(".card");
  await t.page.locator(".card[data-id='1003']").getByLabel("Mark as got").click();
  await settle(t);
  check("got saved", t.fake.lists[CODE].items[1003].got === true && JSON.stringify(t.fake.calls("wl_sh_put_item").pop().body.p_fields) === '["got"]');
  check("got wish has no star button", (await t.page.locator(".card[data-id='1003'] [data-star]").count()) === 0);
  await t.page.locator(".card[data-id='1003']").getByLabel("Mark as not got").click();
  await settle(t);
  check("not got again", t.fake.lists[CODE].items[1003].got === false);
  check("star button back", (await t.page.locator(".card[data-id='1003'] [data-star]").count()) === 1);
  await t.ctx.close();

  // ---- delete with confirmation and Undo ----
  t = await boot({ clock: true });
  await t.page.waitForSelector(".card");
  await t.page.locator(".card[data-id='1001']").getByLabel("Delete", { exact: true }).click();
  check("asks first", (await t.page.locator(".dlg h2").innerText()) === "Delete this wish?");
  await t.page.screenshot({ path: "shot_delete.png" });
  await t.page.getByRole("button", { name: "Cancel" }).click();
  check("cancel keeps it", (await t.page.locator(".card[data-id='1001']").count()) === 1 && t.fake.calls("wl_sh_del_item").length === 0);
  await t.page.locator(".card[data-id='1001']").getByLabel("Delete", { exact: true }).click();
  await t.page.locator(".dlg").getByRole("button", { name: "Delete" }).click();
  check("gone at once", (await t.page.locator(".card[data-id='1001']").count()) === 0);
  check("undo message", /Deleted “Novel”/.test(await t.page.locator("#snack").innerText()));
  check("still online during undo time", !!t.fake.lists[CODE].items[1001] && t.fake.calls("wl_sh_del_item").length === 0);
  await t.page.screenshot({ path: "shot_undo.png" });
  await t.page.locator("#snack").getByRole("button", { name: "Undo" }).click();
  check("undo brings it back, same place", (await t.page.locator(".card").nth(2).getAttribute("data-id")) === "1001");
  check("undo: never deleted online", t.fake.calls("wl_sh_del_item").length === 0 && !!t.fake.lists[CODE].items[1001]);
  check("snack gone", await t.page.locator("#snack").isHidden());
  // really delete: wait out the 10 seconds
  await t.page.locator(".card[data-id='1001']").getByLabel("Delete", { exact: true }).click();
  await t.page.locator(".dlg").getByRole("button", { name: "Delete" }).click();
  await t.page.clock.fastForward(9000);
  check("not yet at 9 s", t.fake.calls("wl_sh_del_item").length === 0);
  await t.page.clock.fastForward(1500);
  await t.page.waitForFunction(() => window.__wl.pending() === 0);
  await sleep(100);
  check("deleted online after 10 s", t.fake.calls("wl_sh_del_item").length === 1 && !t.fake.lists[CODE].items[1001]);
  check("still gone on screen", (await t.page.locator(".card[data-id='1001']").count()) === 0);
  // a second delete finishes the first at once
  await t.page.locator(".card[data-id='1002']").getByLabel("Delete", { exact: true }).click();
  await t.page.locator(".dlg").getByRole("button", { name: "Delete" }).click();
  await t.page.locator(".card[data-id='1003']").getByLabel("Delete", { exact: true }).click();
  await t.page.locator(".dlg").getByRole("button", { name: "Delete" }).click();
  await t.page.waitForFunction(() => window.__wl.pending() === 0);
  await sleep(100);
  check("first delete is final when the next starts", !t.fake.lists[CODE].items[1002] && !!t.fake.lists[CODE].items[1003]);
  check("the second can still be undone", /Lamp|Desk lamp/.test(await t.page.locator("#snack").innerText()));
  check("no js errors", t.errors.length === 0, t.errors);
  await t.ctx.close();

  // instant delete from settings
  t = await boot({ clock: true });
  await t.page.waitForSelector(".card");
  await t.page.getByRole("button", { name: "Settings" }).click();
  await t.page.locator(".dlg").getByLabel("Instant delete").check();
  await t.page.getByRole("button", { name: "Save" }).click();
  await t.page.locator(".card[data-id='1001']").getByLabel("Delete", { exact: true }).click();
  check("instant: no question", (await t.page.locator(".dlg").count()) === 0);
  check("instant: gone and undo offered", (await t.page.locator(".card[data-id='1001']").count()) === 0 && !(await t.page.locator("#snack").isHidden()));
  await t.page.reload();
  await t.page.waitForSelector(".card");
  check("instant delete remembered", await t.page.evaluate(() => localStorage.getItem("wl_instant")) === "1");
  await t.ctx.close();

  // closing the page during the undo time still deletes (sent so it survives the page closing)
  t = await boot({ clock: true });
  await t.page.waitForSelector(".card");
  await t.page.locator(".card[data-id='1001']").getByLabel("Delete", { exact: true }).click();
  await t.page.locator(".dlg").getByRole("button", { name: "Delete" }).click();
  await t.page.evaluate(() => window.dispatchEvent(new Event("pagehide")));
  await sleep(300);
  check("pagehide finishes the delete", t.fake.calls("wl_sh_del_item").length === 1 && !t.fake.lists[CODE].items[1001]);
  await t.ctx.close();
  const failed = summary(); await done(); process.exit(failed ? 1 : 0);
})().catch(async e => { console.log("CRASH", e); await done(); process.exit(1); });
