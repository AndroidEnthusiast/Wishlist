const { boot, done, check, summary, KEY, CODE, sleep } = require("./lib.js");
(async () => {
  // A. bad / missing key
  let t = await boot({ goto: false });
  await t.page.goto(t.base + "edit.html");
  check("no key: says it does not work", /doesn’t work/.test(await t.page.locator("#view").innerText()));
  await t.page.goto(t.base + "edit.html?j=SHORT");
  check("short key: does not work", /doesn’t work/.test(await t.page.locator("#view").innerText()));
  check("no calls for a bad link", t.fake.log.length === 0);
  await t.ctx.close();

  // B. valid-looking key the server does not know
  t = await boot({ key: "ZZZZZZZZZZZZZZZZZZZZ" });
  await t.page.waitForSelector(".inv");
  check("unknown key: gone screen", /doesn’t work anymore/.test(await t.page.locator("#view").innerText()));
  check("unknown key: no editing buttons", await t.page.locator("#fab").isHidden());
  await t.ctx.close();

  // C. loads the list
  t = await boot({ about: "Sizes are small. Thanks!" });
  await t.page.waitForSelector(".card");
  check("title", (await t.page.locator("#name").innerText()) === "Our home");
  check("3 cards", (await t.page.locator(".card").count()) === 3);
  check("about shown", /Sizes are small/.test(await t.page.locator("#about").innerText()));
  check("editing as Sam", /Editing as Sam/.test(await t.page.locator("#who").innerText()));
  const chips = await t.page.locator("#chips .chip").allInnerTexts();
  check("chips", JSON.stringify(chips) === JSON.stringify(["All", "Home", "Fashion", "Books", "Edit categories"]), chips);
  check("star badge only on starred", (await t.page.locator(".card .badge.star").count()) === 1);
  check("got badge", /Got it/.test(await t.page.locator(".card.dim").innerText()));
  check("no star button on a got wish", (await t.page.locator(".card.dim [data-star]").count()) === 0);
  check("price drop badge", /% off/.test(await t.page.locator(".card").first().innerText()));
  check("Added by", /Added by Mia/.test(await t.page.locator(".card").first().innerText()));
  check("note", /White, please/.test(await t.page.locator(".card").first().innerText()));
  check("size tag", /Size M/.test(await t.page.locator(".card").nth(1).innerText()));
  check("no reservation calls", t.fake.calls("wl_get_reservations").length === 0);
  check("no js errors", t.errors.length === 0, t.errors);
  await t.page.screenshot({ path: "shot_list.png" });
  // views
  await t.page.getByLabel("Two per row").click();
  check("grid compact cards", (await t.page.locator(".grid.two .card.compact").count()) === 3);
  check("grid: star buttons on non-got", (await t.page.locator(".card.compact .starbtn").count()) === 2);
  check("grid: starred one is gold", (await t.page.locator(".card.compact .starbtn.on").count()) === 1);
  check("grid: no label text in star buttons", (await t.page.locator(".card.compact .starbtn").allInnerTexts()).every(x => x.trim() === ""));
  await t.page.screenshot({ path: "shot_grid.png" });
  await t.page.getByLabel("Images only").click();
  check("tiles", (await t.page.locator(".tile").count()) === 3);
  await t.page.locator(".tile").first().click();
  check("modal opens with actions", (await t.page.locator("#modal .card .actions .ibtn").count()) === 3);
  await t.page.screenshot({ path: "shot_modal.png" });
  await t.page.keyboard.press("Escape");
  check("escape closes modal", (await t.page.locator("#modal").count()) === 0);
  await t.page.screenshot({ path: "shot_tiles.png" });
  await t.ctx.close();

  // D. first-run name dialog
  t = await boot({ name: null });
  await t.page.waitForSelector(".dlg");
  check("welcome dialog", /What’s your name/.test(await t.page.locator(".dlg h2").innerText()));
  await t.page.screenshot({ path: "shot_welcome.png" });
  await t.page.keyboard.press("Escape");
  check("welcome can't be escaped", (await t.page.locator(".dlg").count()) === 1);
  await t.page.locator(".dlg input").fill("Ana");
  await t.page.getByRole("button", { name: "Save" }).click();
  check("name shown", /Editing as Ana/.test(await t.page.locator("#who").innerText()));
  await t.page.reload();
  await t.page.waitForSelector(".card");
  check("name remembered, no dialog again", (await t.page.locator(".dlg").count()) === 0 && /Editing as Ana/.test(await t.page.locator("#who").innerText()));
  await t.ctx.close();
  const failed = summary(); await done(); process.exit(failed ? 1 : 0);
})().catch(async e => { console.log("CRASH", e); await done(); process.exit(1); });
