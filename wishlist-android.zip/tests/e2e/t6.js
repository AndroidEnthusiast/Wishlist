const { boot, done, check, summary, KEY, CODE, sleep } = require("./lib.js");
const ANDROID = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36";
const IOS = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
(async () => {
  // friends page still fine with the shared stylesheet
  let t = await boot({ goto: false });
  await t.page.goto(t.base + "?c=" + CODE);
  await t.page.waitForSelector(".card");
  check("friends page: 3 cards", (await t.page.locator(".card").count()) === 3);
  check("friends page: styled (card has a radius from wishlist.css)", parseFloat(await t.page.locator(".card").first().evaluate(e => getComputedStyle(e).borderRadius)) > 8);
  await t.page.screenshot({ path: "s_friends.png" });
  check("friends page: no js errors", t.errors.length === 0, t.errors);
  await t.ctx.close();

  // iPhone: invitation link -> editor
  t = await boot({ goto: false, ua: IOS });
  await t.page.goto(t.base + "?j=" + KEY);
  await t.page.waitForURL(u => /edit\.html\?j=/.test(u.toString()));
  await t.page.waitForSelector(".card");
  check("iPhone: the invite link ends in the editor with the list", (await t.page.locator("#name").innerText()) === "Our home" && t.page.url() === t.base + "edit.html?j=" + KEY);
  check("iPhone: back button doesn't trap (history has no invite entry)", await t.page.evaluate(() => history.length) <= 2);
  await t.ctx.close();

  // Android: invitation page with the three buttons; the browser one opens the editor
  t = await boot({ goto: false, ua: ANDROID });
  await t.page.goto(t.base + "?j=" + KEY);
  await t.page.waitForSelector(".inv .btns");
  check("Android: three buttons", JSON.stringify(await t.page.locator(".inv .btns a").allInnerTexts()) === JSON.stringify(["Open in the app", "Download app", "Edit in the browser"]));
  await t.page.screenshot({ path: "s_invite.png" });
  await t.page.getByRole("link", { name: "Edit in the browser" }).click();
  await t.page.waitForSelector(".card");
  check("Android: Edit in the browser opens the editor", /edit\.html\?j=/.test(t.page.url()) && (await t.page.locator(".card").count()) === 3);
  await t.ctx.close();

  // a link to the editor with a broken key
  t = await boot({ goto: false });
  await t.page.goto(t.base + "edit.html?j=NOTAKEY");
  await t.page.waitForFunction(() => /doesn’t work|does not work/i.test(document.body.innerText));
  check("editor: a bad link says so", true);
  await t.ctx.close();
  const failed = summary(); await done(); process.exit(failed ? 1 : 0);
})().catch(async e => { console.log("CRASH", e); await done(); process.exit(1); });
